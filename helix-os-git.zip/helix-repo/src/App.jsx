import React, { useState, useEffect, useRef, useCallback, useMemo } from "react";
import {
  LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, ReferenceLine, CartesianGrid,
} from "recharts";

/* ════════════════════════════════════════════════════════════════════
   HELIX OS v3 — self-improving agentic operating system
   New in v3:
   • GENOME PROFILES — five independent domain lineages (general /
     clinical / dev / finance / design), each seeded with domain
     heuristics, each evolving separately. Auto-routing classifies
     your task and switches profiles for you.
   • ◉ TRAIN — self-play: the system writes its own practice tasks
     targeting its current weaknesses and runs full cycles unattended.
   • DEEP execution — multi-step plan execution for complex tasks.
   • RESEARCH — executor gains live web search when enabled.
   • Adaptive mutation pressure — optimizer aggression scales with
     the fitness trend (plateau → aggressive, climbing → conservative).
   • Migrates v1/v2 state automatically.
   ════════════════════════════════════════════════════════════════════ */

const MODEL = "claude-sonnet-4-6";

/* ───────────────────────────── base agent prompts ─────────────────── */

const BASE_AGENTS = {
  planner:
    "You are PLANNER, the decomposition agent of HELIX OS. Given a task and any relevant episodic memories, produce a minimal execution plan. Respond ONLY with raw JSON, no markdown fences, no prose: {\"strategy\": \"one-sentence approach\", \"steps\": [\"step\", ...]} with at most 5 steps. Steps must be concrete actions the executor can perform in text.",
  executor:
    "You are EXECUTOR, the work agent of HELIX OS. You receive a task, a plan, learned heuristics, and relevant memories. Produce the final deliverable directly — complete, precise, and well structured. Apply every heuristic that is relevant. Do not narrate your process; output only the deliverable.",
  critic:
    "You are CRITIC, the evaluation agent of HELIX OS. Score the deliverable against the original task. Be harsh and specific; a 90+ means near-flawless. Respond ONLY with raw JSON, no markdown fences: {\"score\": 0-100, \"dims\": {\"accuracy\": 0-100, \"depth\": 0-100, \"structure\": 0-100, \"actionability\": 0-100}, \"weaknesses\": [\"specific weakness\", ...], \"memory\": {\"summary\": \"one-sentence lesson worth remembering for future tasks\", \"tags\": [\"tag\", ...]}}",
  optimizer:
    "You are OPTIMIZER, the self-modification agent of HELIX OS. You receive the current agent system prompts, the heuristics bank, the critic's findings, score telemetry, and a PRESSURE directive. Propose minimal surgical mutations to raise future scores. Respond ONLY with raw JSON, no markdown fences: {\"mutate\": true|false, \"note\": \"what changed and why, one sentence\", \"planner\": \"full new planner prompt or null\", \"executor\": \"full new executor prompt or null\", \"add_heuristics\": [\"generalizable rule\", ...], \"retire_heuristics\": [\"exact text of heuristic to remove\", ...]}. Rules: preserve each agent's core role and its output-format contract; heuristics must generalize across tasks, never encode task-specific facts; obey the PRESSURE directive; never add more than 2 heuristics per cycle; if you rewrite a prompt, keep it under 140 words so your JSON never truncates; keep every string value concise.",
};

const TRAINER_PROMPT =
  "You are TRAINER, the self-play curriculum agent of HELIX OS. Generate ONE challenging, realistic practice task in the specified domain that would specifically stress the system's recent weaknesses. The task must be self-contained (answerable in text, no external files) and hard enough that a mediocre attempt would score below 75. Respond ONLY with raw JSON, no markdown fences: {\"task\": \"the full task text\", \"targets\": \"one sentence on which weakness this drills\"}";

const BLIND_JUDGE =
  "You are CRITIC, a blind judge. Two anonymous deliverables answer the same task. Score each 0-100 and pick a winner. You do not know which system produced which. Respond ONLY with raw JSON, no fences: {\"scoreA\": n, \"scoreB\": n, \"winner\": \"A\"|\"B\", \"rationale\": \"one sentence\"}";

/* ───────────────────────────── domain profiles ────────────────────── */

const PROFILES = [
  {
    id: "general", icon: "◎", label: "GENERAL", hue: "#FFB000",
    addendum: "",
    seeds: [],
    keywords: [],
  },
  {
    id: "clinical", icon: "℞", label: "CLINICAL", hue: "#6BCB77",
    addendum: " Domain: clinical medicine. Anchor recommendations to current guidelines and name the source. Use precise dosing, intervals, and lab specifications. For Epic content, use native syntax: *** wildcards, {Name:ID} SmartLists, @SMARTLINK@ tokens.",
    seeds: [
      "Epic content uses native syntax: *** wildcards, {SmartList:ID} with explicit options, @SMARTLINK@ tokens",
      "Anchor clinical recommendations to a named guideline (CDC, USPSTF, IDSA) with year",
      "Patient-facing material targets 6th-grade reading level; Spanish versions include an English back-translation",
    ],
    keywords: ["patient", "clinic", "epic", "smartphrase", "smartlist", "prep", "doxypep", "hiv", "sti", "dose", "dosing", "labs", "screening", "diagnosis", "prophylaxis", "medication", "prior auth", "icd", "cpt", "guideline", "titration", "contraindication", "handout", "counseling", "pdsa", "residency"],
  },
  {
    id: "dev", icon: "⌥", label: "DEV", hue: "#5FD7C5",
    addendum: " Domain: software engineering. Ship complete, runnable code — no placeholders, no TODOs. Include types, error handling, and cleanup paths.",
    seeds: [
      "Code is complete and runnable: types, error handling, abort/cleanup paths — never placeholders or TODOs",
      "State complexity, performance tradeoffs, and edge cases explicitly after the implementation",
    ],
    keywords: ["react", "code", "function", "api", "typescript", "javascript", "python", "component", "hook", "script", "bug", "deploy", "sql", "regex", "endpoint", "refactor", "cli", "vercel", "docker", "state", "props"],
  },
  {
    id: "finance", icon: "◈", label: "FINANCE", hue: "#E0B84E",
    addendum: " Domain: personal finance and quantitative modeling. Show assumptions, formulas, and sensitivity to key variables. Distinguish tax-advantaged vs taxable treatment explicitly.",
    seeds: [
      "Show the math: assumptions, formulas, and sensitivity of the conclusion to key variables",
      "Order tax-advantaged space explicitly (employer match → HSA → Roth → taxable) and justify any deviation",
    ],
    keywords: ["invest", "roth", "401k", "403b", "hsa", "tax", "portfolio", "budget", "loan", "compound", "rebalanc", "allocation", "psls", "pslf", "mortgage", "ledger", "net worth", "dividend", "expense ratio"],
  },
  {
    id: "design", icon: "✎", label: "DESIGN", hue: "#D98CB3",
    addendum: " Domain: interior and product design. Specify concrete materials, dimensions, color values (hex or brand names), and fixture/product classes — never vague vibes. Every aesthetic choice gets a functional justification.",
    seeds: [
      "Specify materials, dimensions, color values, and product classes — never unquantified aesthetic language",
      "Pair every aesthetic choice with its functional justification (sightlines, maintenance, light behavior)",
    ],
    keywords: ["loft", "lighting", "interior", "furniture", "palette", "room", "decor", "layout", "sofa", "rug", "fixture", "shelving", "gallery wall", "color scheme", "apartment"],
  },
];

const PROFILE_MAP = Object.fromEntries(PROFILES.map((p) => [p.id, p]));

function makeGenome(profileId) {
  const p = PROFILE_MAP[profileId];
  return {
    version: 1,
    agents: { ...BASE_AGENTS, executor: BASE_AGENTS.executor + p.addendum },
    heuristics: [...p.seeds],
    history: [],
    note: "genesis",
    ts: Date.now(),
  };
}

function detectProfile(text) {
  const t = (text || "").toLowerCase();
  let best = "general", bestHits = 0;
  for (const p of PROFILES) {
    if (!p.keywords.length) continue;
    const hits = p.keywords.reduce((n, k) => n + (t.includes(k) ? 1 : 0), 0);
    if (hits > bestHits) { bestHits = hits; best = p.id; }
  }
  return bestHits > 0 ? best : "general";
}

/* ───────────────────────────── constants / presets ────────────────── */

const STAGES = ["PLAN", "EXEC", "CRITIC", "EVOLVE"];
const DECAY = 0.92;
const MEM_CAP = 50;
const MEM_FLOOR = 0.15;
const REGRESSION_DELTA = 8;
const TRAIN_ROUNDS = 3;

const PRESETS = [
  { icon: "℞", label: "SmartPhrase: PrEP intake", text: "Draft an Epic SmartPhrase for a PrEP initiation visit: required baseline labs with SmartList options, counseling points, follow-up interval logic, and doxyPEP co-prescribing note. Use *** wildcards and {list} syntax." },
  { icon: "🌐", label: "Spanish patient handout", text: "Write a Spanish-language patient handout (6th-grade reading level) explaining doxyPEP: qué es, cómo tomarlo, efectos secundarios, y cuándo llamar a la clínica. Include an English back-translation." },
  { icon: "◷", label: "QI / PDSA cycle", text: "Design a complete PDSA cycle to raise HIV screening rates in a family medicine residency clinic from 42% to 60% in 90 days: aim statement, measures, change idea, data plan, and run-chart criteria." },
  { icon: "⌥", label: "React hook spec", text: "Spec and implement a production-grade React hook useDebouncedQuery(fn, ms) with abort controller cleanup, stale-result rejection, loading/error state, and TypeScript types." },
  { icon: "◈", label: "Household IPS", text: "Draft an investment policy statement for a dual-income physician household in residency: asset allocation, account priority order (401k match → HSA → backdoor Roth → taxable), rebalancing bands, and behavioral rules." },
  { icon: "✎", label: "Loft lighting plan", text: "Create a layered lighting plan for an open-concept loft: ambient/task/accent zones, color temperature per zone, fixture types, and a dimming scene scheme for evening entertaining." },
];

/* ───────────────────────────── utilities ──────────────────────────── */

const nowStr = () =>
  new Date().toLocaleTimeString("en-US", { hour12: false }) +
  "." + String(Date.now() % 1000).padStart(3, "0");

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

/* escape raw control chars that models emit inside JSON string literals */
function sanitizeJSONStrings(s) {
  let out = "", inStr = false, esc = false;
  for (const ch of s) {
    if (inStr) {
      if (esc) { out += ch; esc = false; continue; }
      if (ch === "\\") { out += ch; esc = true; continue; }
      if (ch === '"') { inStr = false; out += ch; continue; }
      if (ch === "\n") { out += "\\n"; continue; }
      if (ch === "\t") { out += "\\t"; continue; }
      if (ch === "\r") { continue; }
      out += ch;
    } else {
      if (ch === '"') inStr = true;
      out += ch;
    }
  }
  return out;
}

/* close any brackets/strings left open by token-limit truncation */
function autoCloseJSON(s) {
  let inStr = false, esc = false;
  const stack = [];
  for (const ch of s) {
    if (inStr) {
      if (esc) { esc = false; continue; }
      if (ch === "\\") { esc = true; continue; }
      if (ch === '"') inStr = false;
      continue;
    }
    if (ch === '"') inStr = true;
    else if (ch === "{" || ch === "[") stack.push(ch);
    else if (ch === "}" || ch === "]") stack.pop();
  }
  let t = s;
  if (inStr) t += '"';
  t = t.replace(/,\s*$/, "");
  while (stack.length) t += stack.pop() === "{" ? "}" : "]";
  return t;
}

function parseTolerant(text) {
  if (!text) throw new Error("empty model response");
  let t = text.replace(/```json|```/gi, "").trim();
  const a = t.indexOf("{");
  if (a === -1) throw new Error("no JSON object in response");
  t = t.slice(a);
  const b = t.lastIndexOf("}");
  const primary = b !== -1 ? t.slice(0, b + 1) : t;
  const candidates = [];
  candidates.push(primary);
  const clean = sanitizeJSONStrings(primary);
  candidates.push(clean);
  candidates.push(clean.replace(/,\s*([}\]])/g, "$1"));
  candidates.push(autoCloseJSON(sanitizeJSONStrings(t))); // truncation recovery on full tail
  let lastErr;
  for (const c of candidates) {
    try { return JSON.parse(c); } catch (e) { lastErr = e; }
  }
  throw new Error("unparseable JSON: " + (lastErr?.message || "unknown"));
}

/* extract text from any plausible response envelope shape */
function extractText(data) {
  if (typeof data === "string") return data;
  if (typeof data?.completion === "string") return data.completion;
  const content = data?.content ?? data?.message?.content;
  if (typeof content === "string") return content;
  if (Array.isArray(content)) {
    return content.map((b) => {
      if (typeof b === "string") return b;
      if (typeof b?.text === "string") return b.text;
      if (Array.isArray(b?.content)) return b.content.map((c) => (typeof c?.text === "string" ? c.text : "")).join("\n");
      return "";
    }).filter(Boolean).join("\n");
  }
  return "";
}

/* ── standalone I/O layer ──
   All model calls route through this deployment's own serverless proxy
   (/api/helix), which holds the Anthropic key server-side. The client
   keeps retry-with-backoff, a 120s timeout, and a ring-buffer fault
   trace. No artifact bridge, no request-shape guessing — one owned path. */

let kernelLogSink = null;         // wired to the kernel log by the component
const FAULT_TRACE = [];           // last 12 request-level failures
function getFaultTrace() { return FAULT_TRACE; }

/* timeout without AbortSignal — AbortSignal is not structured-cloneable and
   detonates any environment whose fetch shim marshals options over postMessage
   (DataCloneError: "The object can not be cloned"). Promise.race is inert. */
function withTimeout(promise, ms) {
  let timer;
  return Promise.race([
    promise.finally(() => clearTimeout(timer)),
    new Promise((_, rej) => { timer = setTimeout(() => rej(new Error(`request timeout after ${ms / 1000}s`)), ms); }),
  ]);
}

const USER_KEY_K = "helix:userKey";
function getUserKey() {
  try { return localStorage.getItem(USER_KEY_K) || ""; } catch { return ""; }
}
function setUserKey(v) {
  try { v ? localStorage.setItem(USER_KEY_K, v) : localStorage.removeItem(USER_KEY_K); } catch { /* noop */ }
}

async function serverCall(payload, timeoutMs = 120000) {
  return withTimeout((async () => {
    const headers = { "content-type": "application/json" };
    const uk = getUserKey();
    if (uk) headers["x-user-key"] = uk;
    const res = await fetch("/api/helix", { method: "POST", headers, body: JSON.stringify(payload) });
    const raw = await res.text();
    let data;
    try { data = JSON.parse(raw); }
    catch { throw new Error(`http ${res.status} :: non-JSON proxy response :: ${raw.slice(0, 140)}`); }
    if (!res.ok || data.error) {
      throw new Error(`http ${res.status} :: ${data.error || "error"} :: ${data.message || ""}`.trim());
    }
    if (!data.text || !String(data.text).trim()) {
      throw new Error(`empty model response (stop: ${data.stop || "?"})`);
    }
    return data.text;
  })(), timeoutMs);
}

/* direct browser → Anthropic transport (client-side deployments with no /api).
   Uses the operator's own key from localStorage with Anthropic's documented
   CORS header for browser access. */
async function directCall(payload, timeoutMs = 120000) {
  const key = getUserKey();
  if (!key) throw new Error("no_api_key :: tap 🔑 KEY and paste a key from console.anthropic.com");
  return withTimeout((async () => {
    const body = {
      model: "claude-sonnet-4-6",
      max_tokens: Math.max(64, Math.min(payload.maxTokens || 2000, 4096)),
      messages: [{ role: "user", content: payload.user }],
    };
    if (payload.system) body.system = payload.system;
    if (payload.research) body.tools = [{ type: "web_search_20250305", name: "web_search", max_uses: 3 }];
    const res = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "content-type": "application/json",
        "x-api-key": key,
        "anthropic-version": "2023-06-01",
        "anthropic-dangerous-direct-browser-access": "true",
      },
      body: JSON.stringify(body),
    });
    const raw = await res.text();
    let data;
    try { data = JSON.parse(raw); }
    catch { throw new Error(`http ${res.status} :: non-JSON API response :: ${raw.slice(0, 140)}`); }
    if (data.error) throw new Error(`http ${res.status} :: ${data.error.type || "api_error"} :: ${data.error.message || ""}`);
    const text = (data.content || []).filter((b) => b.type === "text").map((b) => b.text).join("\n");
    if (!text.trim()) throw new Error(`empty model response (stop: ${data.stop_reason || "?"})`);
    return text;
  })(), timeoutMs);
}

/* transport mode: "proxy" (this deployment has /api functions) or "direct".
   Detected at boot from /api/health; defaults to trying proxy first. */
let TRANSPORT = "auto";
function setTransport(mode) { TRANSPORT = mode; }
function getTransport() { return TRANSPORT; }

async function invoke(system, user, opts = {}) {
  const attempts = opts.attempts ?? 3;
  const payload = { system, user, maxTokens: opts.maxTokens || 2000, research: !!opts.research };
  let lastErr;
  for (let i = 0; i < attempts; i++) {
    const useDirect = TRANSPORT === "direct" || (TRANSPORT === "auto" && i > 0);
    try {
      const text = useDirect ? await directCall(payload) : await serverCall(payload);
      if (TRANSPORT === "auto") {
        TRANSPORT = useDirect ? "direct" : "proxy";
        kernelLogSink?.(`transport locked :: ${TRANSPORT.toUpperCase()}`, "sys");
      }
      return text;
    } catch (e) {
      lastErr = e;
      FAULT_TRACE.push({
        t: new Date().toISOString(), attempt: i + 1, shape: useDirect ? "direct" : "proxy",
        msg: String(e.message || e).slice(0, 220),
      });
      if (FAULT_TRACE.length > 12) FAULT_TRACE.shift();
      // deterministic auth failures — don't burn retries
      if (/no_api_key|authentication_error|401|permission_error|403|credit|billing|balance/i.test(String(e.message))) break;
      if (i < attempts - 1) await sleep(1000 * (i + 1) + Math.random() * 400);
    }
  }
  throw lastErr;
}

/* invoke expecting JSON: tolerant parse, then one LLM self-repair pass, then one clean retry */
async function invokeJSON(system, user, opts = {}) {
  const raw = await invoke(system, user, opts);
  try { return parseTolerant(raw); } catch (e1) {
    try {
      const fixed = await invoke(
        "You repair malformed JSON. Respond ONLY with the corrected, complete, valid JSON object — no fences, no commentary. If the input is truncated, complete it plausibly and minimally.",
        "Repair this into valid JSON:\n" + raw.slice(0, 6000),
        { maxTokens: opts.maxTokens || 1000 }
      );
      return parseTolerant(fixed);
    } catch (e2) {
      const retried = await invoke(system, user + "\n\nCRITICAL: your previous response was invalid JSON. Respond ONLY with the raw JSON object — no markdown fences, no prose, keep all string values concise.", opts);
      return parseTolerant(retried);
    }
  }
}

const memFallback = {};
const store = {
  degraded: false,
  async get(key) {
    try { const v = localStorage.getItem(key); return v ? JSON.parse(v) : null; }
    catch { return memFallback[key] ?? null; }
  },
  async set(key, value) {
    memFallback[key] = value;
    try { localStorage.setItem(key, JSON.stringify(value)); }
    catch { store.degraded = true; }
  },
};

const K = {
  CORE: "helix3:core", MEMORY: "helix3:memory", TELEMETRY: "helix3:telemetry",
  SETTINGS: "helix3:settings", HISTORY: "helix3:history",
  // legacy keys for migration
  OLD_GENOME: "helix:genome", OLD_MEMORY: "helix:memory",
  OLD_TELEMETRY: "helix:telemetry", OLD_HISTORY: "helix:history",
};

function tokenize(s) {
  return (s || "").toLowerCase().split(/[^a-z0-9áéíóúñ]+/).filter((w) => w.length > 3);
}
function retrieve(memory, taskText, profileId, k = 3) {
  const q = new Set(tokenize(taskText));
  return memory
    .map((m) => {
      const words = new Set([...tokenize(m.summary), ...(m.tags || []).map((t) => t.toLowerCase())]);
      let overlap = 0;
      q.forEach((w) => { if (words.has(w)) overlap++; });
      const profileBonus = m.profile === profileId ? 0.6 : 0;
      return { m, rel: overlap + m.salience * 0.5 + profileBonus };
    })
    .filter((x) => x.rel > 0.6)
    .sort((a, b) => b.rel - a.rel)
    .slice(0, k)
    .map((x) => x.m);
}

function copyText(text) {
  try { if (navigator.clipboard?.writeText) { navigator.clipboard.writeText(text); return true; } } catch { /* noop */ }
  try {
    const ta = document.createElement("textarea");
    ta.value = text; document.body.appendChild(ta); ta.select();
    document.execCommand("copy"); document.body.removeChild(ta);
    return true;
  } catch { return false; }
}

/* ───────────────────────────── design tokens ──────────────────────── */

const C = {
  bg: "#0D0B07", panel: "#14110B", panel2: "#1A160E",
  line: "#2B2416", lineSoft: "#211C11",
  amber: "#FFB000", amberDim: "#9A7422", amberGlow: "rgba(255,176,0,0.10)",
  cyan: "#5FD7C5", red: "#E5484D", green: "#6BCB77",
  text: "#EDE4CE", muted: "#8C8267", faint: "#5A5340",
};
const MONO = "'IBM Plex Mono','SF Mono','Fira Code',ui-monospace,monospace";
const SANS = "'IBM Plex Sans','Helvetica Neue',system-ui,sans-serif";

/* ───────────────────────────── micro components ───────────────────── */

const PanelHead = ({ label, right }) => (
  <div style={{
    display: "flex", justifyContent: "space-between", alignItems: "center",
    padding: "7px 12px", borderBottom: `1px solid ${C.line}`,
    background: C.panel2, userSelect: "none", flexShrink: 0, gap: 8, flexWrap: "wrap",
  }}>
    <span style={{ fontSize: 10, letterSpacing: "0.22em", color: C.amberDim, fontWeight: 600 }}>{label}</span>
    {right}
  </div>
);

const Panel = ({ label, right, children, style }) => (
  <div style={{
    background: C.panel, border: `1px solid ${C.line}`,
    display: "flex", flexDirection: "column", minHeight: 0, ...style,
  }}>
    <PanelHead label={label} right={right} />
    <div style={{ flex: 1, minHeight: 0, overflow: "auto" }}>{children}</div>
  </div>
);

const Btn = ({ children, onClick, tone = "amber", disabled, small, solid, title, style }) => {
  const col = tone === "red" ? C.red : tone === "cyan" ? C.cyan : tone === "green" ? C.green : C.amber;
  return (
    <button
      onClick={onClick} disabled={disabled} title={title}
      style={{
        fontFamily: MONO, fontSize: small ? 10 : 12, letterSpacing: "0.08em",
        color: disabled ? C.faint : solid ? "#0D0B07" : col,
        background: solid && !disabled ? col : "transparent",
        border: `1px solid ${disabled ? C.lineSoft : col}${solid ? "" : "55"}`,
        padding: small ? "3px 8px" : "9px 16px",
        cursor: disabled ? "default" : "pointer",
        fontWeight: solid ? 600 : 400,
        transition: "background 120ms, border-color 120ms, opacity 120ms",
        ...style,
      }}
      onMouseEnter={(e) => { if (!disabled && !solid) e.currentTarget.style.background = `${col}18`; }}
      onMouseLeave={(e) => { if (!solid) e.currentTarget.style.background = "transparent"; }}
    >
      {children}
    </button>
  );
};

const Stat = ({ label, value, accent, color }) => (
  <div style={{ display: "flex", flexDirection: "column", alignItems: "flex-end" }}>
    <span style={{ fontSize: 8.5, letterSpacing: "0.18em", color: C.faint }}>{label}</span>
    <span style={{ fontSize: 13, color: color || (accent ? C.amber : C.text), fontWeight: 500 }}>{value}</span>
  </div>
);

const Section = ({ title, children, tone }) => (
  <div style={{ marginBottom: 16 }}>
    <div style={{ fontSize: 10, letterSpacing: "0.2em", color: tone || C.amberDim, marginBottom: 6 }}>{title}</div>
    {children}
  </div>
);

const DimBars = ({ dims }) => {
  if (!dims) return null;
  return (
    <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(180px, 1fr))", gap: "4px 16px" }}>
      {Object.entries(dims).map(([k, v]) => (
        <div key={k} style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <span style={{ fontSize: 9.5, color: C.faint, width: 88, textTransform: "uppercase", letterSpacing: "0.08em" }}>{k}</span>
          <div style={{ flex: 1, height: 4, background: C.lineSoft }}>
            <div style={{ width: `${v}%`, height: "100%", background: v >= 80 ? C.green : v >= 60 ? C.amber : C.red }} />
          </div>
          <span style={{ fontSize: 10, color: C.muted, width: 24, textAlign: "right" }}>{v}</span>
        </div>
      ))}
    </div>
  );
};

const StageTimeline = ({ stages, tick }) => (
  <div style={{ display: "flex", border: `1px solid ${C.lineSoft}` }}>
    {STAGES.map((s, i) => {
      const st = stages[s];
      const state = st?.st;
      const col = state === "ok" ? C.green : state === "run" ? C.amber : state === "err" ? C.red : C.faint;
      const elapsed = st?.t0 ? ((st.t1 || (state === "run" ? tick : st.t0)) - st.t0) / 1000 : null;
      return (
        <div key={s} style={{
          flex: 1, padding: "6px 8px", borderLeft: i > 0 ? `1px solid ${C.lineSoft}` : "none",
          background: state === "run" ? C.amberGlow : "transparent",
        }}>
          <div style={{ fontSize: 9.5, letterSpacing: "0.12em", color: col, animation: state === "run" ? "blink 0.9s step-end infinite" : "none" }}>
            {state === "ok" ? "✓ " : state === "err" ? "✕ " : state === "run" ? "▸ " : "· "}{s}
          </div>
          <div style={{ fontSize: 9, color: C.faint, marginTop: 2 }}>{elapsed != null ? `${elapsed.toFixed(1)}s` : "—"}</div>
        </div>
      );
    })}
  </div>
);

const SegControl = ({ options, value, onChange, small }) => (
  <div style={{ display: "flex", border: `1px solid ${C.line}` }}>
    {options.map((o) => (
      <button key={o.v} onClick={() => onChange(o.v)} title={o.hint}
        style={{
          fontFamily: MONO, fontSize: small ? 9 : 10, letterSpacing: "0.08em",
          padding: small ? "3px 8px" : "5px 10px", cursor: "pointer",
          background: value === o.v ? C.amber : "transparent",
          color: value === o.v ? "#0D0B07" : C.muted,
          border: "none", borderLeft: `1px solid ${C.lineSoft}`,
          fontWeight: value === o.v ? 600 : 400,
        }}>
        {o.l}
      </button>
    ))}
  </div>
);

const Toggle = ({ on, onChange, label, hint }) => (
  <button onClick={() => onChange(!on)} title={hint}
    style={{
      fontFamily: MONO, fontSize: 9, letterSpacing: "0.1em", padding: "4px 9px",
      cursor: "pointer", background: on ? C.cyan : "transparent",
      color: on ? "#0D0B07" : C.muted, border: `1px solid ${on ? C.cyan : C.line}`,
      fontWeight: on ? 600 : 400,
    }}>
    {label} {on ? "ON" : "OFF"}
  </button>
);

const Modal = ({ title, onClose, children }) => (
  <div style={{
    position: "fixed", inset: 0, background: "rgba(5,4,2,0.8)", zIndex: 50,
    display: "flex", alignItems: "center", justifyContent: "center", padding: 16,
  }} onClick={onClose}>
    <div onClick={(e) => e.stopPropagation()} style={{
      width: "min(680px, 100%)", maxHeight: "85vh", overflow: "auto",
      background: C.panel, border: `1px solid ${C.amberDim}`,
    }}>
      <PanelHead label={title} right={<Btn small onClick={onClose}>CLOSE ✕</Btn>} />
      <div style={{ padding: 14 }}>{children}</div>
    </div>
  </div>
);

/* ─────────────────────── markdown-lite renderer ───────────────────── */

function inlineMd(str, kb) {
  const parts = [];
  const re = /(\*\*[^*]+\*\*|`[^`]+`)/g;
  let last = 0, m, i = 0;
  while ((m = re.exec(str))) {
    if (m.index > last) parts.push(str.slice(last, m.index));
    const tok = m[0];
    if (tok.startsWith("**")) parts.push(<b key={`${kb}-${i}`} style={{ color: "#F5EEDB" }}>{tok.slice(2, -2)}</b>);
    else parts.push(<code key={`${kb}-${i}`} style={{ fontFamily: MONO, fontSize: "0.92em", background: "#1A160E", border: `1px solid ${C.lineSoft}`, padding: "0 4px", color: C.cyan }}>{tok.slice(1, -1)}</code>);
    last = m.index + tok.length; i++;
  }
  if (last < str.length) parts.push(str.slice(last));
  return parts;
}

const MdLite = ({ text }) => {
  const blocks = [];
  const lines = (text || "").split("\n");
  let i = 0, key = 0;
  while (i < lines.length) {
    const ln = lines[i];
    if (ln.trim().startsWith("```")) {
      const buf = [];
      i++;
      while (i < lines.length && !lines[i].trim().startsWith("```")) { buf.push(lines[i]); i++; }
      i++;
      blocks.push(
        <pre key={key++} style={{ fontFamily: MONO, fontSize: 11.5, lineHeight: 1.6, background: "#0A0805", border: `1px solid ${C.lineSoft}`, padding: 10, overflowX: "auto", margin: "8px 0", color: C.text }}>
          {buf.join("\n")}
        </pre>
      );
      continue;
    }
    const h = ln.match(/^(#{1,3})\s+(.*)/);
    if (h) {
      const lvl = h[1].length;
      blocks.push(
        <div key={key++} style={{ fontFamily: MONO, fontSize: lvl === 1 ? 13.5 : lvl === 2 ? 12.5 : 11.5, letterSpacing: "0.08em", color: C.amber, margin: "12px 0 4px", fontWeight: 600 }}>
          {inlineMd(h[2], key)}
        </div>
      );
      i++; continue;
    }
    if (/^\s*([-*•]|\d+[.)])\s+/.test(ln)) {
      const items = [];
      while (i < lines.length && /^\s*([-*•]|\d+[.)])\s+/.test(lines[i])) {
        items.push(lines[i].replace(/^\s*([-*•]|\d+[.)])\s+/, ""));
        i++;
      }
      blocks.push(
        <ul key={key++} style={{ margin: "4px 0", paddingLeft: 18 }}>
          {items.map((it, j) => <li key={j} style={{ marginBottom: 3 }}>{inlineMd(it, `${key}-${j}`)}</li>)}
        </ul>
      );
      continue;
    }
    if (ln.includes("|") && ln.split("|").length > 2) {
      const buf = [];
      while (i < lines.length && lines[i].includes("|")) { buf.push(lines[i]); i++; }
      blocks.push(
        <pre key={key++} style={{ fontFamily: MONO, fontSize: 10.5, lineHeight: 1.7, overflowX: "auto", margin: "6px 0", color: C.text }}>
          {buf.join("\n")}
        </pre>
      );
      continue;
    }
    if (!ln.trim()) { blocks.push(<div key={key++} style={{ height: 8 }} />); i++; continue; }
    blocks.push(<div key={key++} style={{ marginBottom: 2 }}>{inlineMd(ln, key)}</div>);
    i++;
  }
  return (
    <div style={{ fontFamily: SANS, fontSize: 13, lineHeight: 1.62, color: C.text, background: C.bg, border: `1px solid ${C.lineSoft}`, padding: 12 }}>
      {blocks}
    </div>
  );
};

/* ───────────────────────────── main app ───────────────────────────── */

export default function HelixOS() {
  const [booted, setBooted] = useState(false);
  const [profiles, setProfiles] = useState(() =>
    Object.fromEntries(PROFILES.map((p) => [p.id, makeGenome(p.id)]))
  );
  const [activeProfile, setActiveProfile] = useState("general");
  const [memory, setMemory] = useState([]);
  const [telemetry, setTelemetry] = useState([]);
  const [taskHistory, setTaskHistory] = useState([]);
  const [settings, setSettings] = useState({ evolveMode: "auto", depth: "fast", research: false, autoRoute: true });
  const [klog, setKlog] = useState([]);
  const [task, setTask] = useState("");
  const [running, setRunning] = useState(false);
  const [training, setTraining] = useState(null); // {round, total, currentTask}
  const trainStopRef = useRef(false);
  const [stages, setStages] = useState({});
  const [tick, setTick] = useState(Date.now());
  const [output, setOutput] = useState(null);
  const [pending, setPending] = useState(null);
  const [openPrompt, setOpenPrompt] = useState(null);
  const [editAgent, setEditAgent] = useState(null);
  const [editText, setEditText] = useState("");
  const [regression, setRegression] = useState(false);
  const [narrow, setNarrow] = useState(typeof window !== "undefined" ? window.innerWidth < 940 : false);
  const [tab, setTab] = useState("RUN");
  const [modal, setModal] = useState(null);
  const [importText, setImportText] = useState("");
  const [keyDraft, setKeyDraft] = useState("");
  const [copied, setCopied] = useState(false);
  const [chartAll, setChartAll] = useState(false);
  const klogRef = useRef(null);
  const profilesRef = useRef(profiles);
  const activeRef = useRef(activeProfile);
  const lastActionRef = useRef(null);
  const [toasts, setToasts] = useState([]);

  const [diagOpen, setDiagOpen] = useState(false);

  useEffect(() => { profilesRef.current = profiles; }, [profiles]);
  useEffect(() => { activeRef.current = activeProfile; }, [activeProfile]);

  const toast = useCallback((msg, tone = "amber") => {
    const id = Math.random().toString(36).slice(2, 7);
    setToasts((t) => [...t.slice(-3), { id, msg, tone }]);
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 2800);
  }, []);

  const genome = profiles[activeProfile];
  const profileMeta = PROFILE_MAP[activeProfile];

  const log = useCallback((line, tone = "sys") => {
    setKlog((k) => [...k.slice(-249), { t: nowStr(), line, tone }]);
  }, []);

  useEffect(() => { kernelLogSink = log; return () => { kernelLogSink = null; }; }, [log]);

  /* ── boot + migration ── */
  useEffect(() => {
    (async () => {
      log("helix S1.1 // standalone boot :: shim-safe I/O (no AbortSignal, no cloneable hazards in fetch init)");
      const [core, m3, t3, s3, h3] = await Promise.all([
        store.get(K.CORE), store.get(K.MEMORY), store.get(K.TELEMETRY),
        store.get(K.SETTINGS), store.get(K.HISTORY),
      ]);
      if (core?.profiles) {
        // ensure any newly-added profiles exist
        const merged = { ...Object.fromEntries(PROFILES.map((p) => [p.id, makeGenome(p.id)])), ...core.profiles };
        setProfiles(merged);
        setActiveProfile(core.activeProfile && merged[core.activeProfile] ? core.activeProfile : "general");
        log(`profiles restored :: ${Object.keys(merged).length} lineages :: active=${core.activeProfile}`);
      } else {
        // migrate v1/v2 → GENERAL lineage
        const [og, om, ot, oh] = await Promise.all([
          store.get(K.OLD_GENOME), store.get(K.OLD_MEMORY), store.get(K.OLD_TELEMETRY), store.get(K.OLD_HISTORY),
        ]);
        const fresh = Object.fromEntries(PROFILES.map((p) => [p.id, makeGenome(p.id)]));
        if (og) {
          fresh.general = og;
          log(`MIGRATION :: v2 genome (v${og.version}, ${og.heuristics.length} heuristics) grafted into GENERAL lineage`, "evolve");
        }
        setProfiles(fresh);
        await store.set(K.CORE, { activeProfile: "general", profiles: fresh });
        if (om && !m3) { setMemory(om.map((x) => ({ ...x, profile: "general" }))); await store.set(K.MEMORY, om.map((x) => ({ ...x, profile: "general" }))); log(`MIGRATION :: ${om.length} memory traces carried forward`, "mem"); }
        if (ot && !t3) { setTelemetry(ot.map((x) => ({ ...x, profile: "general" }))); await store.set(K.TELEMETRY, ot.map((x) => ({ ...x, profile: "general" }))); }
        if (oh && !h3) { setTaskHistory(oh.map((x) => ({ ...x, profile: "general" }))); await store.set(K.HISTORY, oh.map((x) => ({ ...x, profile: "general" }))); }
        if (!og) log("no prior state :: five genesis lineages seeded with domain heuristics");
      }
      if (m3) { setMemory(m3); log(`episodic memory mounted :: ${m3.length} traces`); }
      if (t3) { setTelemetry(t3); log(`telemetry mounted :: ${t3.length} fitness samples`); }
      if (s3) setSettings((s) => ({ ...s, ...s3 }));
      if (h3) setTaskHistory(h3);
      if (store.degraded) log("WARN persistent storage unavailable :: running volatile", "warn");
      log("scheduler online :: agents [PLANNER EXECUTOR CRITIC OPTIMIZER TRAINER]");
      log("I/O :: serverless proxy /api/helix :: 120s timeout :: retry×3 :: fault trace on :: token budgets unlocked (2–4k)");
      try {
        const hr = await fetch("/api/health?t=" + Date.now());
        if (!hr.ok) throw new Error("no proxy");
        const h = await hr.json();
        if (!h.ok) throw new Error("no proxy");
        setTransport("proxy");
        log(`env :: transport=PROXY :: env key=${h.hasEnvKey ? "PRESENT" : "absent"} :: local key=${getUserKey() ? "present" : "absent"} :: storage=localStorage`);
        if (!h.hasEnvKey && !getUserKey()) {
          log("NO API KEY yet :: tap 🔑 KEY and paste one from console.anthropic.com — or set ANTHROPIC_API_KEY in Vercel env vars", "warn");
          setModal("key");
        }
      } catch {
        setTransport("direct");
        log(`env :: transport=DIRECT (client-side deployment, no /api) :: browser → Anthropic API with your local key :: local key=${getUserKey() ? "present" : "ABSENT"} :: storage=localStorage`);
        if (!getUserKey()) {
          log("NO API KEY yet :: tap 🔑 KEY and paste one from console.anthropic.com — takes 60 seconds, stored only in this browser", "warn");
          setModal("key");
        }
      }
      toast("HELIX S1.1 standalone mounted", "green");
      log("ready. pick a starter task, type your own, or hit ◉ TRAIN and watch it teach itself.");
      setBooted(true);
    })();
  }, [log, toast]);

  useEffect(() => {
    const f = () => setNarrow(window.innerWidth < 940);
    window.addEventListener("resize", f);
    return () => window.removeEventListener("resize", f);
  }, []);

  useEffect(() => {
    const goOn = () => log("network :: connectivity restored", "ok");
    const goOff = () => { log("network :: OFFLINE — all API calls will fail until connectivity returns", "err"); toast("network offline", "red"); };
    window.addEventListener("online", goOn);
    window.addEventListener("offline", goOff);
    return () => { window.removeEventListener("online", goOn); window.removeEventListener("offline", goOff); };
  }, [log, toast]);

  useEffect(() => {
    if (!running) return;
    const iv = setInterval(() => setTick(Date.now()), 200);
    return () => clearInterval(iv);
  }, [running]);

  useEffect(() => {
    if (klogRef.current) klogRef.current.scrollTop = klogRef.current.scrollHeight;
  }, [klog, tab]);

  /* regression guard per active profile */
  useEffect(() => {
    const g = profiles[activeProfile];
    const scoped = telemetry.filter((x) => (x.profile || "general") === activeProfile);
    const cur = scoped.filter((x) => x.version === g.version).map((x) => x.score);
    const prev = scoped.filter((x) => x.version === g.version - 1).map((x) => x.score);
    if (cur.length >= 2 && prev.length >= 2) {
      const avg = (a) => a.reduce((s, x) => s + x, 0) / a.length;
      setRegression(avg(prev) - avg(cur) > REGRESSION_DELTA);
    } else setRegression(false);
  }, [telemetry, profiles, activeProfile]);

  const setStage = (name, st) =>
    setStages((prev) => ({
      ...prev,
      [name]: { st, t0: prev[name]?.t0 ?? Date.now(), t1: st === "ok" || st === "err" ? Date.now() : undefined },
    }));

  const commitGenome = useCallback(async (pid, g) => {
    const next = { ...profilesRef.current, [pid]: g };
    profilesRef.current = next;
    setProfiles(next);
    await store.set(K.CORE, { activeProfile: activeRef.current, profiles: next });
    return next;
  }, []);

  const switchProfile = useCallback(async (pid, reason) => {
    activeRef.current = pid;
    setActiveProfile(pid);
    await store.set(K.CORE, { activeProfile: pid, profiles: profilesRef.current });
    if (reason) log(`profile switch :: ${pid.toUpperCase()} lineage mounted :: ${reason}`, "proc");
  }, [log]);

  const saveSettings = useCallback((s) => { setSettings(s); store.set(K.SETTINGS, s); }, []);

  const applyMutationToGenome = (g, mutation) => {
    const snapshot = { version: g.version, agents: g.agents, heuristics: g.heuristics, note: g.note, ts: g.ts };
    let heur = g.heuristics
      .filter((h) => !(mutation.retire_heuristics || []).includes(h))
      .concat((mutation.add_heuristics || []).slice(0, 2));
    heur = [...new Set(heur)].slice(0, 14);
    return {
      version: g.version + 1,
      agents: {
        ...g.agents,
        planner: mutation.planner || g.agents.planner,
        executor: mutation.executor || g.agents.executor,
      },
      heuristics: heur,
      history: [...g.history, snapshot].slice(-10),
      note: mutation.note || "mutation",
      ts: Date.now(),
    };
  };

  /* adaptive mutation pressure from fitness trend */
  const computePressure = (pid) => {
    const scoped = telemetry.filter((x) => (x.profile || "general") === pid).map((x) => x.score);
    if (scoped.length < 4) return { dir: 0, directive: "PRESSURE: insufficient telemetry — mutate only for clear, specific weaknesses." };
    const recent = scoped.slice(-3), prior = scoped.slice(-6, -3);
    const avg = (a) => a.reduce((s, x) => s + x, 0) / a.length;
    const delta = avg(recent) - avg(prior.length ? prior : recent);
    if (delta <= -3) return { dir: -1, directive: "PRESSURE: fitness is DECLINING — be aggressive; rewrite prompts if needed, retire stale heuristics." };
    if (delta < 3) return { dir: 0, directive: "PRESSURE: fitness has PLATEAUED — moderate aggression; add or sharpen heuristics targeting recurring weaknesses." };
    return { dir: 1, directive: "PRESSURE: fitness is CLIMBING — be conservative; prefer mutate=false unless the critic found a novel failure mode." };
  };

  /* ══════════════ core cycle (used by RUN and TRAIN) ══════════════ */
  const runCycleCore = useCallback(async (t0, opts = {}) => {
    let pid = activeProfile;
    if (settings.autoRoute && !opts.training) {
      const detected = detectProfile(t0);
      if (detected !== activeProfile) {
        pid = detected;
        await switchProfile(detected, "auto-routed from task content");
      }
    }
    const g = profilesRef.current[pid];
    const pmeta = PROFILE_MAP[pid];
    setOutput(null); setPending(null);
    setStages({}); setStage("PLAN", "run");
    const taskId = Math.random().toString(36).slice(2, 7);
    log(`spawn pid:${taskId} [${pid.toUpperCase()} v${g.version}]${opts.training ? " (self-play)" : ""} :: "${t0.slice(0, 56)}${t0.length > 56 ? "…" : ""}"`, "proc");

    let mem = memory.map((m) => ({ ...m, salience: m.salience * DECAY })).filter((m) => m.salience > MEM_FLOOR);
    const recalled = retrieve(mem, t0, pid);
    recalled.forEach((r) => {
      const i = mem.findIndex((m) => m.id === r.id);
      if (i >= 0) { mem[i].salience = Math.min(1, mem[i].salience + 0.25); mem[i].uses = (mem[i].uses || 0) + 1; }
    });
    if (recalled.length) log(`memory recall :: ${recalled.length} trace(s) injected`, "mem");

    const memBlock = recalled.length ? "\n\nRELEVANT MEMORIES:\n" + recalled.map((m) => `- ${m.summary}`).join("\n") : "";
    const heurBlock = g.heuristics.length ? "\n\nLEARNED HEURISTICS:\n" + g.heuristics.map((h) => `- ${h}`).join("\n") : "";

    let plan, deliverable, critique, mutation = null;

    /* PLAN — degradable: planner fault falls back to direct execution */
    log(`syscall :: PLANNER.invoke [${pid} v${g.version}]`, "sys");
    try {
      plan = await invokeJSON(g.agents.planner, `TASK:\n${t0}${memBlock}`);
      log(`plan compiled :: ${plan.steps?.length || 0} steps`, "ok");
    } catch (e) {
      plan = { strategy: "direct execution (planner degraded)", steps: [t0.slice(0, 220)], degraded: true };
      log(`PLANNER degraded :: ${e.message} :: falling back to direct execution`, "warn");
    }
    setStage("PLAN", "ok"); setStage("EXEC", "run");

    /* EXEC — fast (single pass) or deep (per-step) */
    const research = settings.research;
    if (research) log("executor granted web_search capability", "sys");
    if (settings.depth === "deep" && (plan.steps || []).length > 1) {
      const steps = plan.steps.slice(0, 4);
      let notes = "";
      for (let i = 0; i < steps.length - 1; i++) {
        log(`syscall :: EXECUTOR.invoke :: deep step ${i + 1}/${steps.length}`, "sys");
        const partial = await invoke(
          g.agents.executor,
          `TASK:\n${t0}\n\nFULL PLAN:\n${JSON.stringify(plan)}\n\nWORK SO FAR:\n${notes || "(none)"}\n\nExecute ONLY step ${i + 1}: "${steps[i]}". Produce concise working output for this step (it feeds later steps, not the user).${heurBlock}`,
          { maxTokens: 1200, research }
        );
        notes += `\n[STEP ${i + 1}: ${steps[i]}]\n${partial}\n`;
      }
      log(`syscall :: EXECUTOR.invoke :: deep synthesis`, "sys");
      deliverable = await invoke(
        g.agents.executor,
        `TASK:\n${t0}\n\nFULL PLAN:\n${JSON.stringify(plan)}\n\nWORKING OUTPUT FROM PRIOR STEPS:\n${notes}\n\nExecute the final step and assemble the complete, polished final deliverable. Output only the deliverable.${heurBlock}${memBlock}`,
        { maxTokens: 2500, research }
      );
    } else {
      log("syscall :: EXECUTOR.invoke", "sys");
      deliverable = await invoke(
        g.agents.executor,
        `TASK:\n${t0}\n\nPLAN:\n${JSON.stringify(plan)}${heurBlock}${memBlock}`,
        { maxTokens: 2500, research }
      );
    }
    setStage("EXEC", "ok"); setStage("CRITIC", "run");
    log(`deliverable produced :: ${deliverable.length} chars`, "ok");

    /* CRITIC — degradable: a critic fault never eats the deliverable */
    log("syscall :: CRITIC.invoke", "sys");
    let criticFailed = false;
    try {
      critique = await invokeJSON(g.agents.critic, `ORIGINAL TASK:\n${t0}\n\nDELIVERABLE:\n${deliverable}`);
      log(`fitness :: ${critique.score}/100 :: ${(critique.weaknesses || []).length} weakness(es)`, critique.score >= 80 ? "ok" : "warn");
    } catch (e) {
      criticFailed = true;
      critique = null;
      log(`CRITIC degraded :: ${e.message} :: deliverable unscored, evolution skipped this cycle`, "warn");
    }
    setStage("CRITIC", criticFailed ? "err" : "ok");

    if (critique?.memory?.summary) {
      mem.push({ id: taskId, summary: critique.memory.summary, tags: critique.memory.tags || [], salience: 1, uses: 0, ts: Date.now(), profile: pid });
      mem = mem.sort((a, b) => b.salience - a.salience).slice(0, MEM_CAP);
      log("episodic trace committed", "mem");
    }

    /* EVOLVE — degradable, and requires a critic verdict */
    let newProfiles = null;
    if (settings.evolveMode === "off" || criticFailed) {
      setStage("EVOLVE", "ok");
      log(criticFailed ? "evolution skipped :: no critic verdict this cycle" : "evolution disabled :: genome frozen", "sys");
    } else {
      setStage("EVOLVE", "run");
      const scoped = telemetry.filter((x) => (x.profile || "general") === pid);
      const recentTel = scoped.slice(-8).map((x) => `v${x.version}:${x.score}`).join(" ");
      const pressure = computePressure(pid);
      log(`syscall :: OPTIMIZER.invoke :: ${pressure.dir < 0 ? "aggressive" : pressure.dir > 0 ? "conservative" : "moderate"} pressure`, "sys");
      try {
      mutation = await invokeJSON(
        g.agents.optimizer,
        `CURRENT GENOME [${pid.toUpperCase()}] v${g.version}\n\nPLANNER PROMPT:\n${g.agents.planner}\n\nEXECUTOR PROMPT:\n${g.agents.executor}\n\nHEURISTICS:\n${g.heuristics.map((h) => "- " + h).join("\n") || "(none)"}\n\nCRITIC FINDINGS (score ${critique.score}):\n${JSON.stringify(critique.weaknesses)}\n\nSCORE TELEMETRY: ${recentTel || "(none)"}\nCURRENT SCORE: ${critique.score}\n\n${pressure.directive}`
      );
      setStage("EVOLVE", "ok");
      if (mutation.mutate) {
        if (settings.evolveMode === "approve" && !opts.training) {
          setPending({ ...mutation, profile: pid });
          log(`mutation PROPOSED :: awaiting operator approval :: ${mutation.note}`, "evolve");
        } else {
          const ng = applyMutationToGenome(g, mutation);
          newProfiles = await commitGenome(pid, ng);
          log(`GENOME MUTATION [${pid.toUpperCase()}] :: v${g.version} → v${ng.version} :: ${mutation.note}`, "evolve");
          toast(`⟲ ${pid.toUpperCase()} genome evolved → v${ng.version}`);
        }
      } else {
        log(`genome stable :: ${mutation.note || "no selection pressure"}`, "sys");
      }
      } catch (e) {
        mutation = null;
        setStage("EVOLVE", "ok");
        log(`OPTIMIZER degraded :: ${e.message} :: genome unchanged this cycle`, "warn");
      }
    }

    /* persist */
    const tel = critique ? [...telemetry, {
      ts: Date.now(), version: g.version, score: critique.score, dims: critique.dims,
      task: t0.slice(0, 80), kind: opts.training ? "train" : "task", profile: pid,
    }].slice(-160) : telemetry;
    const hist = [{
      id: taskId, ts: Date.now(), task: t0, score: critique ? critique.score : null, version: g.version, profile: pid,
      training: !!opts.training,
      deliverable: deliverable.slice(0, 5000), plan,
      critique: critique ? { score: critique.score, dims: critique.dims, weaknesses: (critique.weaknesses || []).slice(0, 6) } : null,
    }, ...taskHistory].slice(0, 20);
    setTelemetry(tel); setMemory(mem); setTaskHistory(hist);
    await Promise.all([
      store.set(K.TELEMETRY, tel), store.set(K.MEMORY, mem), store.set(K.HISTORY, hist),
    ]);
    log(`pid:${taskId} exit 0 :: state persisted`, "ok");
    setOutput({
      task: t0, plan, deliverable, critique, criticFailed, profile: pid,
      mutation: settings.evolveMode === "approve" && !opts.training ? null : mutation,
      training: !!opts.training,
    });
    return { critique };
  }, [activeProfile, settings, memory, telemetry, taskHistory, log, switchProfile, commitGenome, toast]);

  const selfTest = useCallback(async () => {
    log("⚕ SELF-TEST :: probing deployment…", "sys");
    let health = { hasEnvKey: false };
    try {
      const r = await fetch("/api/health?t=" + Date.now());
      if (!r.ok) throw new Error("no proxy");
      health = await r.json();
      if (!health.ok) throw new Error("no proxy");
      setTransport("proxy");
      log(`⚕ transport :: PROXY :: env key ${health.hasEnvKey ? "PRESENT" : "absent"} :: local key ${getUserKey() ? "present" : "absent"}`, "ok");
    } catch {
      setTransport("direct");
      log(`⚕ transport :: DIRECT (browser → Anthropic) :: local key ${getUserKey() ? "present" : "ABSENT"}`, "ok");
    }
    if (!health.hasEnvKey && !getUserKey()) {
      log("⚕ verdict :: NO API KEY. two fixes: (a) permanent — add ANTHROPIC_API_KEY in Vercel → Project → Settings → Environment Variables, then redeploy; (b) instant — tap KEY in the top bar and paste a key from console.anthropic.com (stored only in this browser).", "warn");
      toast("⚕ no API key — tap KEY to add one", "red");
      setModal("key");
      return;
    }
    const t0 = Date.now();
    try {
      const r = await invoke("Reply with exactly: OK", "ping", { attempts: 1, maxTokens: 64 });
      log(`⚕ model round-trip :: PASS :: "${r.trim().slice(0, 12)}" in ${Date.now() - t0}ms`, "ok");
      log("⚕ verdict :: deployment healthy — proxy up, key valid, model responding. clear to run.", "ok");
      toast(`⚕ healthy · ${Date.now() - t0}ms`, "green");
    } catch (e) {
      log(`⚕ model round-trip :: FAIL :: ${e.message}`, "err");
      if (/authentication|401/i.test(e.message)) {
        log("⚕ verdict :: key rejected — invalid, revoked, or mistyped. tap KEY and re-paste, or fix the Vercel env var.", "err");
        toast("⚕ API key rejected — tap KEY", "red");
        setModal("key");
      } else if (/credit|billing|balance|purchase/i.test(e.message)) {
        log("⚕ verdict :: NO API CREDITS. your API key is valid but the console account isn't funded — API billing is separate from your Claude app subscription. fix: console.anthropic.com → Billing → add credits ($5 min). self-test goes green the moment it's funded.", "err");
        toast("⚕ no API credits — fund at console.anthropic.com", "red");
      } else if (/rate.?limit|429/i.test(e.message)) {
        log("⚕ verdict :: rate-limited at the API — wait a minute and retry. add credits at console.anthropic.com if this persists.", "warn");
        toast("⚕ rate-limited — wait and retry", "red");
      } else if (/failed to fetch|networkerror|load failed/i.test(e.message)) {
        log("⚕ verdict :: browser-level fetch failure — the request never reached Anthropic. causes: CORS blocked in this browser/network, a VPN or content blocker, or offline. try another network or browser and re-test; if it persists, copy this log to Claude and we'll switch transports.", "err");
        toast("⚕ network/CORS blocked — see log", "red");
      } else {
        log("⚕ verdict :: transport is up but the model call failed — the exact error is in the FAIL line above. ⧉ COPY this log and paste it to Claude for a targeted fix.", "err");
        toast("⚕ model call failed — copy log to Claude", "red");
      }
    }
  }, [log, toast]);

  const runCycle = useCallback(async () => {
    const t0 = task.trim();
    if (!t0 || running) return;
    lastActionRef.current = () => runCycle();
    setRunning(true);
    try { await runCycleCore(t0); }
    catch (e) {
      log(`FAULT :: ${e.message}`, "err");
      toast("✕ cycle fault — tap RETRY", "red");
      setStages((s) => {
        const next = { ...s };
        for (const st of STAGES) if (next[st]?.st === "run") next[st] = { ...next[st], st: "err", t1: Date.now() };
        return next;
      });
      setOutput((o) => o || { task: t0, error: e.message });
    }
    finally { setRunning(false); }
  }, [task, running, runCycleCore, log, toast]);

  /* ══════════════ TRAIN — self-play curriculum ══════════════ */
  const train = useCallback(async () => {
    if (running) return;
    lastActionRef.current = () => train();
    setRunning(true);
    trainStopRef.current = false;
    const pid = activeProfile;
    log(`◉ SELF-PLAY :: ${TRAIN_ROUNDS} rounds :: [${pid.toUpperCase()}] lineage training itself`, "evolve");
    try {
      for (let r = 1; r <= TRAIN_ROUNDS; r++) {
        if (trainStopRef.current) { log(`self-play halted by operator after ${r - 1} round(s)`, "warn"); break; }
        setTraining({ round: r, total: TRAIN_ROUNDS });
        const g = profiles[pid];
        const scoped = telemetry.filter((x) => (x.profile || "general") === pid);
        const recentWeak = taskHistory
          .filter((h) => (h.profile || "general") === pid)
          .slice(0, 3)
          .flatMap((h) => h.critique?.weaknesses || [])
          .slice(0, 6);
        log(`syscall :: TRAINER.invoke :: generating curriculum round ${r}/${TRAIN_ROUNDS}`, "sys");
        const gen = await invokeJSON(
          TRAINER_PROMPT,
          `DOMAIN: ${PROFILE_MAP[pid].label} (${pid})\n\nRECENT WEAKNESSES TO DRILL:\n${recentWeak.map((w) => "- " + w).join("\n") || "(none logged — generate a broadly challenging task)"}\n\nRECENT SCORES: ${scoped.slice(-5).map((x) => x.score).join(", ") || "(none)"}\n\nHEURISTICS ALREADY LEARNED (avoid tasks these fully solve):\n${g.heuristics.map((h) => "- " + h).join("\n") || "(none)"}`
        );
        log(`curriculum :: "${gen.task.slice(0, 70)}…" :: drills: ${gen.targets}`, "proc");
        setTraining({ round: r, total: TRAIN_ROUNDS, currentTask: gen.task });
        await runCycleCore(gen.task, { training: true });
      }
      log("◉ SELF-PLAY COMPLETE :: check telemetry + heuristics bank for gains", "evolve");
      toast("◉ self-play complete", "green");
    } catch (e) {
      log(`self-play FAULT :: ${e.message}`, "err");
    } finally {
      setTraining(null);
      setRunning(false);
    }
  }, [running, activeProfile, profiles, telemetry, taskHistory, runCycleCore, log, toast]);

  /* ══════════════ refine ══════════════ */
  const refine = useCallback(async () => {
    if (!output?.deliverable || !output?.critique || running) return;
    lastActionRef.current = () => refine();
    setRunning(true);
    const pid = output.profile || activeProfile;
    const g = profiles[pid];
    setStages({}); setStage("EXEC", "run");
    log("refine loop :: EXECUTOR revising against critic findings", "proc");
    try {
      const revised = await invoke(
        g.agents.executor,
        `TASK:\n${output.task}\n\nYOUR PREVIOUS DELIVERABLE:\n${output.deliverable}\n\nCRITIC WEAKNESSES TO FIX:\n${(output.critique.weaknesses || []).map((w) => "- " + w).join("\n")}\n\nProduce a revised deliverable that fixes every weakness while preserving everything that was correct. Output only the revised deliverable.`,
        { maxTokens: 2500, research: settings.research }
      );
      setStage("EXEC", "ok"); setStage("CRITIC", "run");
      let crit2 = null;
      try {
        crit2 = await invokeJSON(g.agents.critic, `ORIGINAL TASK:\n${output.task}\n\nDELIVERABLE:\n${revised}`);
        setStage("CRITIC", "ok");
        const delta = crit2.score - (output.critique?.score ?? 0);
        log(`refine complete :: ${output.critique?.score ?? "?"} → ${crit2.score} (${delta >= 0 ? "+" : ""}${delta})`, delta >= 0 ? "ok" : "warn");
        const tel = [...telemetry, { ts: Date.now(), version: g.version, score: crit2.score, dims: crit2.dims, task: output.task.slice(0, 80), kind: "refine", profile: pid }].slice(-160);
        setTelemetry(tel); await store.set(K.TELEMETRY, tel);
      } catch (e) {
        setStage("CRITIC", "err");
        log(`refine CRITIC degraded :: ${e.message} :: revision kept, unscored`, "warn");
      }
      setOutput((o) => ({ ...o, deliverable: revised, critique: crit2 || o.critique, criticFailed: !crit2, refined: true }));
    } catch (e) {
      log(`refine FAULT :: ${e.message}`, "err");
    } finally { setRunning(false); }
  }, [output, running, profiles, activeProfile, settings, telemetry, log]);

  /* ══════════════ tournament ══════════════ */
  const tournament = useCallback(async () => {
    const t0 = task.trim();
    const g = profiles[activeProfile];
    const incumbent = g.history[g.history.length - 1];
    if (!t0 || running || !incumbent) return;
    lastActionRef.current = () => tournament();
    setRunning(true); setOutput(null); setPending(null);
    setStages({}); setStage("PLAN", "run");
    log(`⚔ TOURNAMENT [${activeProfile.toUpperCase()}] :: v${g.version} (challenger) vs v${incumbent.version} (incumbent)`, "evolve");

    const runG = async (agents, heuristics) => {
      const heurBlock = heuristics.length ? "\n\nLEARNED HEURISTICS:\n" + heuristics.map((h) => `- ${h}`).join("\n") : "";
      const plan = await invokeJSON(agents.planner, `TASK:\n${t0}`);
      return invoke(agents.executor, `TASK:\n${t0}\n\nPLAN:\n${JSON.stringify(plan)}${heurBlock}`, { maxTokens: 2500 });
    };

    try {
      log("syscall :: challenger pipeline", "sys");
      const outA = await runG(g.agents, g.heuristics);
      setStage("PLAN", "ok"); setStage("EXEC", "run");
      log("syscall :: incumbent pipeline", "sys");
      const outB = await runG(incumbent.agents, incumbent.heuristics);
      setStage("EXEC", "ok"); setStage("CRITIC", "run");
      log("syscall :: CRITIC blind comparison", "sys");
      let verdict;
      try {
        verdict = await invokeJSON(BLIND_JUDGE, `TASK:\n${t0}\n\nDELIVERABLE A:\n${outA}\n\nDELIVERABLE B:\n${outB}`);
      } catch (e) {
        log(`JUDGE degraded :: ${e.message} :: no verdict, genome unchanged, showing challenger output`, "warn");
        setStage("CRITIC", "err"); setStage("EVOLVE", "ok");
        setOutput({ task: t0, profile: activeProfile, deliverable: outA, judgeFailed: true });
        return;
      }
      setStage("CRITIC", "ok"); setStage("EVOLVE", "run");

      const challengerWon = verdict.winner === "A";
      log(`verdict :: A(v${g.version})=${verdict.scoreA} B(v${incumbent.version})=${verdict.scoreB} :: ${verdict.rationale}`, "ok");

      let rolledBack = false;
      if (!challengerWon && verdict.scoreB - verdict.scoreA > 5) {
        const ng = { ...incumbent, history: g.history.slice(0, -1), version: g.version + 1, note: `tournament loss → restored v${incumbent.version} material`, ts: Date.now() };
        await commitGenome(activeProfile, ng);
        rolledBack = true;
        log(`TOURNAMENT ROLLBACK :: incumbent defeats challenger by >5 :: genome reverted`, "evolve");
      } else {
        log(`challenger v${g.version} ${challengerWon ? "holds the throne" : "survives (margin ≤5)"}`, "evolve");
      }
      setStage("EVOLVE", "ok");

      const tel = [...telemetry, { ts: Date.now(), version: g.version, score: verdict.scoreA, task: t0.slice(0, 80), kind: "tournament", profile: activeProfile }].slice(-160);
      setTelemetry(tel); await store.set(K.TELEMETRY, tel);
      setOutput({
        task: t0, profile: activeProfile,
        tournament: { verdict, challengerV: g.version, incumbentV: incumbent.version, rolledBack },
        deliverable: challengerWon ? outA : outB,
      });
    } catch (e) {
      log(`tournament FAULT :: ${e.message}`, "err");
      setStages((s) => {
        const next = { ...s };
        for (const st of STAGES) if (next[st]?.st === "run") next[st] = { ...next[st], st: "err", t1: Date.now() };
        return next;
      });
    } finally { setRunning(false); }
  }, [task, running, profiles, activeProfile, telemetry, commitGenome, log]);

  /* ══════════════ mutation approval / rollback / edit / io ═════════ */
  const approvePending = useCallback(async () => {
    if (!pending) return;
    const pid = pending.profile || activeProfile;
    const g = profiles[pid];
    const ng = applyMutationToGenome(g, pending);
    await commitGenome(pid, ng);
    setPending(null);
    log(`mutation APPROVED [${pid.toUpperCase()}] :: v${g.version} → v${ng.version} :: ${pending.note}`, "evolve");
    toast(`✓ mutation applied → v${ng.version}`, "green");
    setOutput((o) => (o ? { ...o, mutation: pending } : o));
  }, [pending, activeProfile, profiles, commitGenome, log, toast]);

  const rejectPending = useCallback(() => {
    if (!pending) return;
    log(`mutation REJECTED by operator :: ${pending.note}`, "warn");
    setPending(null);
  }, [pending, log]);

  const rollback = useCallback(async () => {
    const g = profiles[activeProfile];
    const prev = g.history[g.history.length - 1];
    if (!prev) return;
    const ng = { ...prev, history: g.history.slice(0, -1), version: g.version + 1, note: `rollback → restored v${prev.version} genome`, ts: Date.now() };
    await commitGenome(activeProfile, ng);
    log(`ROLLBACK [${activeProfile.toUpperCase()}] :: restored v${prev.version} material (now v${ng.version})`, "evolve");
    toast(`↩ rolled back to v${prev.version} material`, "cyan");
  }, [profiles, activeProfile, commitGenome, log, toast]);

  const wipe = useCallback(async () => {
    const fresh = Object.fromEntries(PROFILES.map((p) => [p.id, makeGenome(p.id)]));
    setProfiles(fresh); setMemory([]); setTelemetry([]); setTaskHistory([]); setPending(null);
    setActiveProfile("general");
    await Promise.all([
      store.set(K.CORE, { activeProfile: "general", profiles: fresh }),
      store.set(K.MEMORY, []), store.set(K.TELEMETRY, []), store.set(K.HISTORY, []),
    ]);
    log("SYSTEM RESET :: all lineages restored to genesis, state purged", "warn");
  }, [log]);

  const startEdit = (agent) => { setEditAgent(agent); setEditText(genome.agents[agent]); };
  const saveEdit = useCallback(async () => {
    if (!editAgent) return;
    const g = profiles[activeProfile];
    const snapshot = { version: g.version, agents: g.agents, heuristics: g.heuristics, note: g.note, ts: g.ts };
    const ng = {
      ...g, version: g.version + 1,
      agents: { ...g.agents, [editAgent]: editText },
      history: [...g.history, snapshot].slice(-10),
      note: `manual edit :: ${editAgent} prompt rewritten by operator`, ts: Date.now(),
    };
    await commitGenome(activeProfile, ng);
    setEditAgent(null);
    log(`MANUAL MUTATION [${activeProfile.toUpperCase()}] :: operator rewrote ${editAgent.toUpperCase()} :: v${ng.version}`, "evolve");
  }, [editAgent, editText, profiles, activeProfile, commitGenome, log]);

  const doImport = useCallback(async () => {
    try {
      const parsed = JSON.parse(importText);
      if (!parsed.agents?.planner || !parsed.agents?.executor) throw new Error("missing agent prompts");
      const g = profiles[activeProfile];
      const snapshot = { version: g.version, agents: g.agents, heuristics: g.heuristics, note: g.note, ts: g.ts };
      const ng = {
        version: g.version + 1,
        agents: { ...g.agents, ...parsed.agents },
        heuristics: Array.isArray(parsed.heuristics) ? parsed.heuristics.slice(0, 14) : g.heuristics,
        history: [...g.history, snapshot].slice(-10),
        note: "genome imported by operator", ts: Date.now(),
      };
      await commitGenome(activeProfile, ng);
      setModal(null); setImportText("");
      log(`GENOME IMPORT [${activeProfile.toUpperCase()}] :: v${ng.version} :: foreign genome grafted`, "evolve");
    } catch (e) { log(`import FAULT :: ${e.message}`, "err"); }
  }, [importText, profiles, activeProfile, commitGenome, log]);

  /* ══════════════ derived ══════════════ */
  const scopedTel = useMemo(
    () => telemetry.filter((x) => chartAll || (x.profile || "general") === activeProfile),
    [telemetry, activeProfile, chartAll]
  );
  const fitness = useMemo(() => {
    const last5 = scopedTel.slice(-5).map((x) => x.score);
    return last5.length ? Math.round(last5.reduce((s, x) => s + x, 0) / last5.length) : null;
  }, [scopedTel]);
  const trend = useMemo(() => {
    const s = scopedTel.map((x) => x.score);
    if (s.length < 4) return null;
    const avg = (a) => a.reduce((x, y) => x + y, 0) / a.length;
    return Math.round(avg(s.slice(-3)) - avg(s.slice(-6, -3)));
  }, [scopedTel]);
  const chartData = useMemo(() => scopedTel.map((x, i) => ({ i: i + 1, score: x.score, v: x.version, kind: x.kind, p: x.profile })), [scopedTel]);
  const detectedProfile = useMemo(() => (settings.autoRoute && task.trim() ? detectProfile(task) : null), [task, settings.autoRoute]);
  const toneColor = { sys: C.muted, ok: C.green, warn: C.amber, err: C.red, proc: C.cyan, mem: C.cyan, evolve: C.amber };

  /* ══════════════ panels ══════════════ */

  const profileStrip = (
    <div style={{ display: "flex", gap: 4, flexWrap: "wrap", alignItems: "center" }}>
      {PROFILES.map((p) => {
        const active = p.id === activeProfile;
        const suggested = detectedProfile === p.id && !active;
        return (
          <button key={p.id} onClick={() => switchProfile(p.id, "operator selection")}
            title={`${p.label} lineage — v${profiles[p.id].version}, ${profiles[p.id].heuristics.length} heuristics`}
            style={{
              fontFamily: MONO, fontSize: 9.5, letterSpacing: "0.1em", padding: "4px 9px",
              cursor: "pointer",
              background: active ? p.hue : "transparent",
              color: active ? "#0D0B07" : suggested ? p.hue : C.muted,
              border: `1px solid ${active || suggested ? p.hue : C.lineSoft}`,
              fontWeight: active ? 600 : 400,
              animation: suggested ? "blink 1.2s step-end infinite" : "none",
            }}>
            {p.icon} {p.label} <span style={{ opacity: 0.7 }}>v{profiles[p.id].version}</span>
          </button>
        );
      })}
      <Toggle on={settings.autoRoute} onChange={(v) => saveSettings({ ...settings, autoRoute: v })}
        label="AUTO-ROUTE" hint="classify each task and switch to the matching lineage automatically" />
    </div>
  );

  const consolePanel = (
    <Panel label={`CONSOLE // ${profileMeta.icon} ${profileMeta.label} LINEAGE`} right={
      <div style={{ display: "flex", gap: 6 }}>
        <Btn small tone="green" onClick={selfTest} disabled={running} title="checks proxy → key → model round-trip and reports the verdict">⚕ SELF-TEST</Btn>
        <Btn small onClick={() => setModal("key")} title="manage the Anthropic API key used by this deployment">🔑 KEY</Btn>
        <Btn small tone="cyan" onClick={() => setModal("help")}>HOW IT WORKS ?</Btn>
      </div>
    } style={{ height: "100%" }}>
      <div style={{ padding: 12, display: "flex", flexDirection: "column", gap: 10, minHeight: "100%", boxSizing: "border-box" }}>
        {profileStrip}

        <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
          {PRESETS.map((p) => (
            <button key={p.label} onClick={() => !running && setTask(p.text)} disabled={running}
              style={{
                fontFamily: MONO, fontSize: 10, color: running ? C.faint : C.muted, background: C.panel2,
                border: `1px solid ${C.lineSoft}`, padding: "4px 9px", cursor: "pointer", letterSpacing: "0.04em",
              }}
              onMouseEnter={(e) => { e.currentTarget.style.borderColor = C.amberDim; e.currentTarget.style.color = C.text; }}
              onMouseLeave={(e) => { e.currentTarget.style.borderColor = C.lineSoft; e.currentTarget.style.color = C.muted; }}>
              <span style={{ color: C.amberDim }}>{p.icon}</span> {p.label}
            </button>
          ))}
        </div>

        <textarea
          value={task} onChange={(e) => setTask(e.target.value)}
          onKeyDown={(e) => { if (e.key === "Enter" && (e.metaKey || e.ctrlKey)) runCycle(); }}
          placeholder="describe any task, tap a starter, or hit ◉ TRAIN to let it teach itself…  (⌘↵ to run)"
          rows={3}
          style={{
            width: "100%", boxSizing: "border-box", resize: "vertical",
            background: C.bg, color: C.text, border: `1px solid ${C.line}`,
            fontFamily: MONO, fontSize: 12, padding: 10, lineHeight: 1.5,
          }} />

        <div style={{ display: "flex", gap: 8, alignItems: "center", flexWrap: "wrap" }}>
          <Btn solid onClick={runCycle} disabled={running || !booted || !task.trim()} style={{ flex: narrow ? "1 1 100%" : "0 0 auto" }}>
            {running && !training ? "CYCLE RUNNING…" : "▶ RUN CYCLE"}
          </Btn>
          <Btn tone="green" onClick={train} disabled={running || !booted}
            title={`self-play: TRAINER writes ${TRAIN_ROUNDS} practice tasks targeting recent weaknesses and runs full cycles on each`}>
            ◉ TRAIN ×{TRAIN_ROUNDS}
          </Btn>
          <Btn tone="cyan" onClick={tournament} disabled={running || !task.trim() || !genome.history.length}
            title={genome.history.length ? "pit current genome against the previous version, blind-judged" : "needs ≥1 prior genome version in this lineage"}>
            ⚔ TOURNAMENT
          </Btn>
        </div>

        <div style={{ display: "flex", gap: 10, alignItems: "center", flexWrap: "wrap" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
            <span style={{ fontSize: 9, color: C.faint, letterSpacing: "0.1em" }}>EVOLVE</span>
            <SegControl small value={settings.evolveMode}
              onChange={(v) => saveSettings({ ...settings, evolveMode: v })}
              options={[
                { v: "auto", l: "AUTO", hint: "apply mutations automatically" },
                { v: "approve", l: "APPROVE", hint: "review each mutation before it lands" },
                { v: "off", l: "OFF", hint: "freeze the genome" },
              ]} />
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
            <span style={{ fontSize: 9, color: C.faint, letterSpacing: "0.1em" }}>DEPTH</span>
            <SegControl small value={settings.depth}
              onChange={(v) => saveSettings({ ...settings, depth: v })}
              options={[
                { v: "fast", l: "FAST", hint: "single-pass execution — quickest" },
                { v: "deep", l: "DEEP", hint: "executes the plan step-by-step, then synthesizes — slower, stronger on complex tasks" },
              ]} />
          </div>
          <Toggle on={settings.research} onChange={(v) => saveSettings({ ...settings, research: v })}
            label="🔍 RESEARCH" hint="grant the executor live web search — use for tasks needing current guidelines, prices, or events" />
        </div>

        <StageTimeline stages={stages} tick={tick} />

        {training && (
          <div style={{ border: `1px solid ${C.green}66`, background: `${C.green}10`, padding: 10 }}>
            <div style={{ fontSize: 10, letterSpacing: "0.18em", color: C.green, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
              <span>◉ SELF-PLAY :: ROUND {training.round}/{training.total}</span>
              <Btn small tone="red" onClick={() => { trainStopRef.current = true; }}>HALT AFTER ROUND</Btn>
            </div>
            {training.currentTask && (
              <div style={{ fontSize: 10.5, color: C.muted, marginTop: 6, lineHeight: 1.5 }}>
                drilling: {training.currentTask.slice(0, 140)}{training.currentTask.length > 140 ? "…" : ""}
              </div>
            )}
          </div>
        )}

        {pending && (
          <div style={{ border: `1px solid ${C.amber}`, background: C.amberGlow, padding: 12 }}>
            <div style={{ fontSize: 10, letterSpacing: "0.2em", color: C.amber, marginBottom: 6 }}>
              ⚠ PENDING MUTATION [{(pending.profile || activeProfile).toUpperCase()}] :: v{profiles[pending.profile || activeProfile].version} → v{profiles[pending.profile || activeProfile].version + 1}
            </div>
            <div style={{ fontSize: 11.5, color: C.text, lineHeight: 1.6, marginBottom: 6 }}>{pending.note}</div>
            {(pending.add_heuristics || []).map((h, i) => <div key={i} style={{ fontSize: 11, color: C.green }}>+ {h}</div>)}
            {(pending.retire_heuristics || []).map((h, i) => <div key={i} style={{ fontSize: 11, color: C.red }}>− {h}</div>)}
            {pending.planner && <div style={{ fontSize: 10.5, color: C.cyan, marginTop: 4 }}>Δ planner prompt rewritten</div>}
            {pending.executor && <div style={{ fontSize: 10.5, color: C.cyan }}>Δ executor prompt rewritten</div>}
            <div style={{ display: "flex", gap: 8, marginTop: 10 }}>
              <Btn small tone="green" onClick={approvePending}>APPLY MUTATION</Btn>
              <Btn small tone="red" onClick={rejectPending}>DISCARD</Btn>
            </div>
          </div>
        )}

        <div style={{ flex: 1, minHeight: 0, borderTop: `1px solid ${C.lineSoft}`, paddingTop: 10 }}>
          {!output && !running && (
            <div style={{ color: C.faint, fontSize: 11, lineHeight: 1.9 }}>
              <div style={{ color: C.amberDim }}>PLAN → EXEC → CRITIC → EVOLVE ⟲ genome</div>
              <div style={{ marginTop: 8 }}>Five independent genome lineages, each learning its own domain.</div>
              <div>Auto-route reads your task and mounts the right one.</div>
              <div style={{ marginTop: 8 }}>◉ TRAIN makes it write its own practice tasks aimed at its weaknesses —</div>
              <div>run it a few times and check telemetry for the climb.</div>
            </div>
          )}
          {output && (
            <div style={{ animation: "scan 200ms ease-out" }}>
              {output.tournament && (
                <Section title={`⚔ TOURNAMENT :: v${output.tournament.challengerV} vs v${output.tournament.incumbentV}`} tone={C.cyan}>
                  <div style={{ fontSize: 12, color: C.text, lineHeight: 1.7 }}>
                    challenger v{output.tournament.challengerV}: <b style={{ color: output.tournament.verdict.winner === "A" ? C.green : C.red }}>{output.tournament.verdict.scoreA}</b>
                    {"  ·  "}
                    incumbent v{output.tournament.incumbentV}: <b style={{ color: output.tournament.verdict.winner === "B" ? C.green : C.red }}>{output.tournament.verdict.scoreB}</b>
                  </div>
                  <div style={{ fontSize: 11, color: C.muted, marginTop: 4 }}>{output.tournament.verdict.rationale}</div>
                  {output.tournament.rolledBack && <div style={{ fontSize: 11, color: C.amber, marginTop: 4 }}>→ genome rolled back to incumbent material</div>}
                </Section>
              )}
              {output.training && (
                <Section title="◉ SELF-PLAY TASK" tone={C.green}>
                  <div style={{ fontSize: 11, color: C.muted, lineHeight: 1.6 }}>{output.task}</div>
                </Section>
              )}
              {output.plan && (
                <Section title={`PLAN :: ${output.plan.strategy || ""}`}>
                  <ol style={{ margin: 0, paddingLeft: 18, fontSize: 11, color: C.muted, lineHeight: 1.7 }}>
                    {(output.plan.steps || []).map((s, i) => <li key={i}>{s}</li>)}
                  </ol>
                </Section>
              )}
              {output.deliverable && (
                <Section title={output.refined ? "DELIVERABLE (REFINED)" : "DELIVERABLE"}>
                  <MdLite text={output.deliverable} />
                  <div style={{ display: "flex", gap: 8, marginTop: 8, flexWrap: "wrap" }}>
                    <Btn small onClick={() => { copyText(output.deliverable); setCopied(true); toast("⧉ copied to clipboard", "cyan"); setTimeout(() => setCopied(false), 1500); }}>
                      {copied ? "✓ COPIED" : "⧉ COPY"}
                    </Btn>
                    {output.critique && (
                      <Btn small tone="cyan" onClick={refine} disabled={running}
                        title="executor revises against the critic's weaknesses, then re-scores">
                        ↻ REFINE ({(output.critique.weaknesses || []).length} fixes)
                      </Btn>
                    )}
                  </div>
                </Section>
              )}
              {output.criticFailed && (
                <Section title="CRITIC :: DEGRADED (UNSCORED)" tone={C.red}>
                  <div style={{ fontSize: 11, color: C.muted, lineHeight: 1.6 }}>
                    the deliverable above is intact — only scoring failed this cycle, so evolution was skipped. run ⚕ SELF-TEST if this repeats.
                  </div>
                </Section>
              )}
              {output.judgeFailed && (
                <Section title="⚔ JUDGE :: DEGRADED" tone={C.red}>
                  <div style={{ fontSize: 11, color: C.muted, lineHeight: 1.6 }}>
                    both genomes produced output but the blind judge failed — no verdict, genome unchanged. challenger's deliverable shown above.
                  </div>
                </Section>
              )}
              {output.critique && !output.criticFailed && (
                <Section title={`CRITIC :: ${output.critique.score}/100`}>
                  <DimBars dims={output.critique.dims} />
                  {(output.critique.weaknesses || []).length > 0 && (
                    <ul style={{ margin: "8px 0 0", paddingLeft: 16, fontSize: 11, color: C.muted, lineHeight: 1.7 }}>
                      {output.critique.weaknesses.map((w, i) => <li key={i}>{w}</li>)}
                    </ul>
                  )}
                </Section>
              )}
              {output.mutation && (
                <Section title={output.mutation.mutate ? "EVOLVE :: GENOME MUTATED" : "EVOLVE :: STABLE"}>
                  <div style={{ fontSize: 11, color: output.mutation.mutate ? C.amber : C.muted, lineHeight: 1.6 }}>{output.mutation.note}</div>
                  {(output.mutation.add_heuristics || []).map((h, i) => <div key={i} style={{ fontSize: 11, color: C.green, marginTop: 4 }}>+ {h}</div>)}
                  {(output.mutation.retire_heuristics || []).map((h, i) => <div key={i} style={{ fontSize: 11, color: C.red, marginTop: 4 }}>− {h}</div>)}
                </Section>
              )}
              {output.error && (
                <Section title="FAULT" tone={C.red}>
                  <div style={{ fontSize: 11, color: C.red, lineHeight: 1.6 }}>{output.error}</div>
                  <div style={{ fontSize: 10.5, color: C.muted, marginTop: 4, lineHeight: 1.6 }}>
                    every call was retried ×3 with backoff before this surfaced. run ⚕ SELF-TEST — it checks the proxy, the key, and the model in sequence and tells you exactly which layer failed.
                  </div>
                  <div style={{ display: "flex", gap: 8, marginTop: 8, flexWrap: "wrap" }}>
                    <Btn small tone="red" onClick={() => lastActionRef.current && lastActionRef.current()} disabled={running}>⟳ RETRY</Btn>
                    <Btn small tone="cyan" onClick={selfTest} disabled={running}>⚕ SELF-TEST</Btn>
                    <Btn small onClick={() => setDiagOpen(!diagOpen)}>{diagOpen ? "HIDE DIAG" : "SHOW DIAG"}</Btn>
                  </div>
                  {diagOpen && (
                    <div style={{ marginTop: 8 }}>
                      <pre style={{ fontFamily: MONO, fontSize: 9.5, lineHeight: 1.6, color: C.muted, background: "#0A0805", border: `1px solid ${C.lineSoft}`, padding: 8, overflowX: "auto", whiteSpace: "pre-wrap", margin: 0 }}>
                        {getFaultTrace().length ? getFaultTrace().map((f) => `[${f.t}] attempt ${f.attempt} · ${f.shape}\n  ${f.msg}`).join("\n") : "(trace empty)"}
                      </pre>
                      <div style={{ marginTop: 6 }}>
                        <Btn small onClick={() => { copyText(JSON.stringify(getFaultTrace(), null, 2)); toast("⧉ diag trace copied — paste it to Claude", "cyan"); }}>⧉ COPY TRACE</Btn>
                      </div>
                    </div>
                  )}
                </Section>
              )}
            </div>
          )}
        </div>
      </div>
    </Panel>
  );

  const genomePanel = (
    <Panel
      label={`GENOME [${profileMeta.label}] v${genome.version}`}
      right={
        <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
          <Btn small tone="cyan" onClick={() => setModal("export")}>EXPORT</Btn>
          <Btn small tone="cyan" onClick={() => { setImportText(""); setModal("import"); }}>IMPORT</Btn>
          <Btn small tone="cyan" onClick={rollback} disabled={!genome.history.length}>ROLLBACK</Btn>
          <Btn small tone="red" onClick={wipe}>RESET ALL</Btn>
        </div>
      }
      style={{ height: "100%" }}
    >
      <div style={{ padding: 10 }}>
        <div style={{ fontSize: 10, color: C.faint, marginBottom: 8 }}>last mutation :: {genome.note}</div>
        {["planner", "executor", "critic", "optimizer"].map((a) => {
          const evolvable = a === "planner" || a === "executor";
          return (
            <div key={a} style={{ marginBottom: 6 }}>
              <button onClick={() => setOpenPrompt(openPrompt === a ? null : a)}
                style={{
                  width: "100%", textAlign: "left", background: C.panel2,
                  border: `1px solid ${C.lineSoft}`, color: C.text, fontFamily: MONO,
                  fontSize: 11, padding: "6px 10px", cursor: "pointer",
                  display: "flex", justifyContent: "space-between",
                }}>
                <span style={{ color: evolvable ? C.amberDim : C.faint }}>
                  {a.toUpperCase()}{evolvable ? " (evolves)" : " (fixed judge)"}
                </span>
                <span style={{ color: C.faint }}>{openPrompt === a ? "−" : "+"}</span>
              </button>
              {openPrompt === a && (
                <div style={{ border: `1px solid ${C.lineSoft}`, borderTop: "none", padding: 10 }}>
                  {editAgent === a ? (
                    <>
                      <textarea value={editText} onChange={(e) => setEditText(e.target.value)} rows={8}
                        style={{ width: "100%", boxSizing: "border-box", background: C.bg, color: C.text, border: `1px solid ${C.amberDim}`, fontFamily: MONO, fontSize: 10.5, padding: 8, lineHeight: 1.6 }} />
                      <div style={{ display: "flex", gap: 8, marginTop: 6 }}>
                        <Btn small tone="green" onClick={saveEdit}>COMMIT MANUAL MUTATION</Btn>
                        <Btn small onClick={() => setEditAgent(null)}>CANCEL</Btn>
                      </div>
                    </>
                  ) : (
                    <>
                      <div style={{ fontSize: 10.5, color: C.muted, lineHeight: 1.6, whiteSpace: "pre-wrap" }}>{genome.agents[a]}</div>
                      <div style={{ marginTop: 8 }}>
                        <Btn small onClick={() => startEdit(a)}
                          title={evolvable ? "hand-edit this prompt (versioned like any mutation)" : "editing the judge changes what the system optimizes toward — proceed deliberately"}>
                          ✎ EDIT PROMPT
                        </Btn>
                      </div>
                    </>
                  )}
                </div>
              )}
            </div>
          );
        })}

        <div style={{ fontSize: 10, letterSpacing: "0.18em", color: C.amberDim, margin: "12px 0 6px" }}>
          HEURISTICS BANK ({genome.heuristics.length})
        </div>
        {genome.heuristics.length === 0 && <div style={{ fontSize: 11, color: C.faint }}>empty — heuristics are learned from critic feedback</div>}
        {genome.heuristics.map((h, i) => (
          <div key={i} style={{
            fontSize: 11, color: C.text, padding: "5px 8px", marginBottom: 4,
            borderLeft: `2px solid ${profileMeta.hue}`, background: C.amberGlow, lineHeight: 1.5,
            display: "flex", justifyContent: "space-between", gap: 8,
          }}>
            <span>{h}</span>
            <button onClick={async () => {
              const g = profiles[activeProfile];
              const ng = { ...g, heuristics: g.heuristics.filter((_, j) => j !== i) };
              await commitGenome(activeProfile, ng);
              log("heuristic retired by operator", "warn");
            }} title="retire this heuristic"
              style={{ background: "none", border: "none", color: C.faint, cursor: "pointer", fontFamily: MONO, fontSize: 11 }}>✕</button>
          </div>
        ))}

        {genome.history.length > 0 && (
          <>
            <div style={{ fontSize: 10, letterSpacing: "0.18em", color: C.amberDim, margin: "12px 0 6px" }}>LINEAGE</div>
            {[...genome.history].reverse().map((s) => (
              <div key={s.version + "-" + s.ts} style={{ fontSize: 10.5, color: C.faint, marginBottom: 3 }}>
                v{s.version} :: {s.note} :: {new Date(s.ts).toLocaleDateString()}
              </div>
            ))}
          </>
        )}
      </div>
    </Panel>
  );

  const telemetryPanel = (
    <Panel label={`FITNESS ${chartAll ? ":: ALL LINEAGES" : `:: ${profileMeta.label}`}`}
      right={<Btn small onClick={() => setChartAll(!chartAll)}>{chartAll ? "SCOPE: ALL" : "SCOPE: LINEAGE"}</Btn>}
      style={{ height: "100%" }}>
      {chartData.length < 2 ? (
        <div style={{ padding: 14, fontSize: 11, color: C.faint }}>
          run ≥2 cycles in this lineage to plot fitness. dashed line = 80 target.
        </div>
      ) : (
        <div style={{ width: "100%", height: "100%", minHeight: 130, padding: "8px 4px 0 0", boxSizing: "border-box" }}>
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={chartData} margin={{ top: 6, right: 10, bottom: 2, left: -18 }}>
              <CartesianGrid stroke={C.lineSoft} strokeDasharray="2 4" />
              <XAxis dataKey="i" tick={{ fill: C.faint, fontSize: 9, fontFamily: MONO }} stroke={C.line} />
              <YAxis domain={[0, 100]} tick={{ fill: C.faint, fontSize: 9, fontFamily: MONO }} stroke={C.line} />
              <Tooltip
                contentStyle={{ background: C.panel2, border: `1px solid ${C.line}`, fontFamily: MONO, fontSize: 11 }}
                labelStyle={{ color: C.muted }}
                formatter={(v, n, p) => [`${v} · ${p.payload.p || "general"} v${p.payload.v}${p.payload.kind && p.payload.kind !== "task" ? " · " + p.payload.kind : ""}`, "fitness"]} />
              <ReferenceLine y={80} stroke={C.amberDim} strokeDasharray="4 4" />
              <Line type="monotone" dataKey="score" stroke={C.amber} strokeWidth={1.5}
                dot={{ r: 2.5, fill: C.amber, stroke: "none" }} isAnimationActive={false} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      )}
    </Panel>
  );

  const memoryPanel = (
    <Panel label={`EPISODIC MEMORY // λ=${DECAY}`} style={{ height: "100%" }}>
      <div style={{ padding: 10 }}>
        {memory.length === 0 && (
          <div style={{ fontSize: 11, color: C.faint }}>
            no traces yet. the critic commits one lesson per task; salience decays each cycle, recall reinforces, same-lineage traces retrieve preferentially.
          </div>
        )}
        {[...memory].sort((a, b) => b.salience - a.salience).map((m) => (
          <div key={m.id} style={{ marginBottom: 8 }}>
            <div style={{ fontSize: 11, color: C.text, lineHeight: 1.5 }}>
              <span style={{ color: PROFILE_MAP[m.profile || "general"]?.hue || C.faint, marginRight: 6 }}>
                {PROFILE_MAP[m.profile || "general"]?.icon || "◎"}
              </span>
              {m.summary}
            </div>
            <div style={{ display: "flex", alignItems: "center", gap: 8, marginTop: 3 }}>
              <div style={{ flex: 1, height: 3, background: C.lineSoft }}>
                <div style={{ width: `${Math.round(m.salience * 100)}%`, height: "100%", background: m.salience > 0.5 ? C.cyan : C.faint }} />
              </div>
              <span style={{ fontSize: 9, color: C.faint }}>s={m.salience.toFixed(2)} · ×{m.uses || 0}</span>
            </div>
          </div>
        ))}
      </div>
    </Panel>
  );

  const historyPanel = (
    <Panel label={`TASK HISTORY (${taskHistory.length})`} style={{ height: "100%" }}>
      <div style={{ padding: 10 }}>
        {taskHistory.length === 0 && (
          <div style={{ fontSize: 11, color: C.faint }}>completed cycles land here — view any past deliverable or re-run it against the evolved genome.</div>
        )}
        {taskHistory.map((h) => (
          <div key={h.id} style={{ border: `1px solid ${C.lineSoft}`, padding: "8px 10px", marginBottom: 6 }}>
            <div style={{ fontSize: 11, color: C.text, lineHeight: 1.5 }}>
              <span style={{ color: PROFILE_MAP[h.profile || "general"]?.hue || C.faint, marginRight: 6 }}>
                {PROFILE_MAP[h.profile || "general"]?.icon}{h.training ? "◉" : ""}
              </span>
              {h.task.slice(0, 105)}{h.task.length > 105 ? "…" : ""}
            </div>
            <div style={{ display: "flex", alignItems: "center", gap: 10, marginTop: 5, flexWrap: "wrap" }}>
              <span style={{ fontSize: 10, color: h.score == null ? C.faint : h.score >= 80 ? C.green : h.score >= 60 ? C.amber : C.red }}>{h.score == null ? "unscored" : `${h.score}/100`}</span>
              <span style={{ fontSize: 9.5, color: C.faint }}>v{h.version} · {new Date(h.ts).toLocaleString()}</span>
              <div style={{ marginLeft: "auto", display: "flex", gap: 6 }}>
                <Btn small onClick={() => {
                  setOutput({ task: h.task, plan: h.plan, deliverable: h.deliverable, critique: h.critique, profile: h.profile });
                  if (narrow) setTab("RUN");
                }}>VIEW</Btn>
                <Btn small tone="cyan" onClick={() => { setTask(h.task); if (narrow) setTab("RUN"); }}
                  title="load into console — re-running shows whether the evolved genome beats this score">↺ RE-RUN</Btn>
              </div>
            </div>
          </div>
        ))}
      </div>
    </Panel>
  );

  const kernelLogPanel = (
    <div style={{ height: "100%", display: "flex", flexDirection: "column", background: "#0A0805", border: `1px solid ${C.line}` }}>
      <PanelHead label="KERNEL LOG" right={
        <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
          <Btn small onClick={() => { copyText(klog.map((l) => `[${l.t}] ${l.line}`).join("\n")); toast("⧉ kernel log copied — paste it to Claude for triage", "cyan"); }}>⧉ COPY</Btn>
          <span style={{ fontSize: 9, color: C.faint }}>{klog.length} lines</span>
        </div>
      } />
      <div ref={klogRef} style={{ flex: 1, overflow: "auto", padding: "6px 12px" }}>
        {klog.map((l, i) => (
          <div key={i} style={{ fontSize: 10.5, lineHeight: 1.7, whiteSpace: "pre-wrap" }}>
            <span style={{ color: C.faint }}>[{l.t}] </span>
            <span style={{ color: toneColor[l.tone] || C.muted }}>{l.line}</span>
          </div>
        ))}
      </div>
    </div>
  );

  const TABS = [
    { id: "RUN", node: consolePanel },
    { id: "GENOME", node: genomePanel },
    { id: "DATA", node: <div style={{ display: "grid", gridTemplateRows: "1fr 1fr", gap: 10, height: "100%" }}>{telemetryPanel}{memoryPanel}</div> },
    { id: "HISTORY", node: historyPanel },
    { id: "LOG", node: kernelLogPanel },
  ];

  /* ══════════════ render ══════════════ */
  return (
    <div style={{
      fontFamily: MONO, background: C.bg, color: C.text, height: "100vh",
      display: "flex", flexDirection: "column", overflow: "hidden",
    }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@400;500;600&family=IBM+Plex+Sans:wght@400;500&display=swap');
        *::-webkit-scrollbar { width: 8px; height: 8px; }
        *::-webkit-scrollbar-thumb { background: ${C.line}; }
        *::-webkit-scrollbar-track { background: transparent; }
        textarea:focus, button:focus-visible { outline: 1px solid ${C.amber}; outline-offset: 1px; }
        @media (prefers-reduced-motion: reduce) { * { animation: none !important; transition: none !important; } }
        @keyframes blink { 50% { opacity: 0.2; } }
        @keyframes scan { from { opacity: 0; transform: translateY(2px);} to { opacity: 1; transform: none;} }
      `}</style>

      <div style={{
        display: "flex", alignItems: "center", gap: 14, padding: "10px 14px",
        borderBottom: `1px solid ${C.line}`, background: C.panel, flexWrap: "wrap", flexShrink: 0,
      }}>
        <div style={{ display: "flex", alignItems: "baseline", gap: 10 }}>
          <span style={{ fontSize: 17, fontWeight: 600, letterSpacing: "0.28em", color: C.amber }}>HELIX</span>
          <span style={{ fontSize: 9, fontWeight: 700, color: "#0D0B07", background: C.amber, padding: "2px 6px", letterSpacing: "0.1em" }}>S1.1</span>
          {!narrow && <span style={{ fontSize: 10, color: C.faint, letterSpacing: "0.2em" }}>SELF-MODIFYING AGENT KERNEL</span>}
        </div>
        <div style={{ flex: 1 }} />
        <Stat label="LINEAGE" value={`${profileMeta.icon} v${genome.version}`} color={profileMeta.hue} />
        <Stat label="HEUR" value={genome.heuristics.length} />
        <Stat label="TRACES" value={memory.length} />
        <Stat label="FIT·5" value={fitness ?? "—"} accent={fitness !== null && fitness >= 80} />
        {trend !== null && (
          <Stat label="TREND" value={`${trend > 0 ? "▲" : trend < 0 ? "▼" : "▬"}${Math.abs(trend)}`}
            color={trend > 0 ? C.green : trend < 0 ? C.red : C.muted} />
        )}
        {running && <span style={{ fontSize: 10, color: C.amber, animation: "blink 1s step-end infinite" }}>● ACTIVE</span>}
      </div>

      {regression && (
        <div style={{
          padding: "6px 14px", background: `${C.red}14`, borderBottom: `1px solid ${C.red}44`,
          fontSize: 11, color: C.red, display: "flex", alignItems: "center", gap: 12, flexWrap: "wrap", flexShrink: 0,
        }}>
          REGRESSION GUARD [{profileMeta.label}] :: v{genome.version} underperforms v{genome.version - 1} by &gt;{REGRESSION_DELTA} pts
          <Btn tone="red" small onClick={rollback}>ROLLBACK GENOME</Btn>
        </div>
      )}

      {narrow ? (
        <>
          <div style={{ flex: 1, minHeight: 0, padding: 8 }}>{TABS.find((t) => t.id === tab)?.node}</div>
          <div style={{ display: "flex", borderTop: `1px solid ${C.line}`, background: C.panel, flexShrink: 0 }}>
            {TABS.map((t) => (
              <button key={t.id} onClick={() => setTab(t.id)}
                style={{
                  flex: 1, fontFamily: MONO, fontSize: 9.5, letterSpacing: "0.12em",
                  padding: "12px 4px", cursor: "pointer", background: "transparent",
                  color: tab === t.id ? C.amber : C.faint, border: "none",
                  borderTop: `2px solid ${tab === t.id ? C.amber : "transparent"}`,
                }}>
                {t.id}
              </button>
            ))}
          </div>
        </>
      ) : (
        <div style={{ flex: 1, display: "flex", flexDirection: "column", minHeight: 0 }}>
          <div style={{
            flex: 1, display: "grid", gap: 10, padding: 10, minHeight: 0,
            gridTemplateColumns: "minmax(380px, 1.45fr) minmax(330px, 1fr)",
            gridTemplateRows: "minmax(0, 1.35fr) minmax(0, 1fr)",
          }}>
            <div style={{ gridRow: "1 / 3", minHeight: 0 }}>{consolePanel}</div>
            <div style={{ minHeight: 0 }}>{genomePanel}</div>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, minHeight: 0 }}>
              <div style={{ display: "grid", gridTemplateRows: "1fr 1fr", gap: 10, minHeight: 0 }}>
                {telemetryPanel}
                {memoryPanel}
              </div>
              <div style={{ minHeight: 0 }}>{historyPanel}</div>
            </div>
          </div>
          <div style={{ height: 128, padding: "0 10px 10px", flexShrink: 0 }}>{kernelLogPanel}</div>
        </div>
      )}

      {/* toasts */}
      <div style={{ position: "fixed", top: 54, right: 12, zIndex: 60, display: "flex", flexDirection: "column", gap: 6, pointerEvents: "none" }}>
        {toasts.map((t) => {
          const col = t.tone === "red" ? C.red : t.tone === "green" ? C.green : t.tone === "cyan" ? C.cyan : C.amber;
          return (
            <div key={t.id} style={{
              fontFamily: MONO, fontSize: 10.5, letterSpacing: "0.06em", color: col,
              background: "rgba(13,11,7,0.95)", border: `1px solid ${col}66`,
              padding: "7px 12px", animation: "scan 160ms ease-out", maxWidth: 300,
            }}>
              {t.msg}
            </div>
          );
        })}
      </div>

      {modal === "export" && (
        <Modal title={`EXPORT GENOME [${profileMeta.label}]`} onClose={() => setModal(null)}>
          <div style={{ fontSize: 11, color: C.muted, marginBottom: 8 }}>
            Copy this JSON to back up this lineage or graft it into another HELIX instance or profile.
          </div>
          <textarea readOnly
            value={JSON.stringify({ agents: genome.agents, heuristics: genome.heuristics, exportedFrom: `${activeProfile} v${genome.version}` }, null, 2)}
            rows={14} onClick={(e) => e.target.select()}
            style={{ width: "100%", boxSizing: "border-box", background: C.bg, color: C.text, border: `1px solid ${C.line}`, fontFamily: MONO, fontSize: 10.5, padding: 10 }} />
          <div style={{ marginTop: 8 }}>
            <Btn small onClick={() => copyText(JSON.stringify({ agents: genome.agents, heuristics: genome.heuristics }, null, 2))}>⧉ COPY JSON</Btn>
          </div>
        </Modal>
      )}
      {modal === "import" && (
        <Modal title={`IMPORT GENOME → [${profileMeta.label}]`} onClose={() => setModal(null)}>
          <div style={{ fontSize: 11, color: C.muted, marginBottom: 8 }}>
            Paste an exported genome JSON. Grafting into the {profileMeta.label} lineage creates a new version; the current genome snapshots to lineage first, so rollback stays available.
          </div>
          <textarea value={importText} onChange={(e) => setImportText(e.target.value)} rows={12}
            placeholder='{"agents": {"planner": "...", "executor": "..."}, "heuristics": ["..."]}'
            style={{ width: "100%", boxSizing: "border-box", background: C.bg, color: C.text, border: `1px solid ${C.line}`, fontFamily: MONO, fontSize: 10.5, padding: 10 }} />
          <div style={{ marginTop: 8 }}>
            <Btn small tone="green" onClick={doImport} disabled={!importText.trim()}>GRAFT GENOME</Btn>
          </div>
        </Modal>
      )}
      {modal === "key" && (
        <Modal title="API KEY" onClose={() => setModal(null)}>
          <div style={{ fontFamily: SANS, fontSize: 12.5, lineHeight: 1.7, color: C.text }}>
            <p style={{ marginTop: 0 }}>HELIX runs on your own Anthropic API key. Two ways to provide it:</p>
            <p><b style={{ color: C.amber }}>Permanent (recommended):</b> Vercel dashboard → this project → Settings → Environment Variables → add <code style={{ fontFamily: MONO, color: C.cyan }}>ANTHROPIC_API_KEY</code> → redeploy. The key lives server-side only and works on every device automatically.</p>
            <p><b style={{ color: C.amber }}>Instant:</b> paste a key below. It's stored only in this browser's localStorage and sent to your own proxy per request — fine for personal use on your own devices; don't do this on shared computers.</p>
            <p style={{ color: C.muted, fontSize: 11.5 }}>Get a key at console.anthropic.com → API Keys. Pay-per-use; a heavy HELIX session costs cents.</p>
          </div>
          <input
            type="password"
            value={keyDraft}
            onChange={(e) => setKeyDraft(e.target.value)}
            placeholder={getUserKey() ? "•••••••• (local key saved — paste to replace)" : "sk-ant-…"}
            style={{ width: "100%", boxSizing: "border-box", background: C.bg, color: C.text, border: `1px solid ${C.line}`, fontFamily: MONO, fontSize: 12, padding: 10 }}
          />
          <div style={{ display: "flex", gap: 8, marginTop: 10, flexWrap: "wrap" }}>
            <Btn small tone="green" disabled={!keyDraft.trim()} onClick={() => {
              setUserKey(keyDraft.trim()); setKeyDraft(""); setModal(null);
              log("API key saved to this browser :: run ⚕ SELF-TEST to verify", "ok");
              toast("🔑 key saved — run SELF-TEST", "green");
            }}>SAVE KEY</Btn>
            <Btn small tone="red" disabled={!getUserKey()} onClick={() => {
              setUserKey(""); setKeyDraft("");
              log("local API key cleared", "warn");
              toast("🔑 local key cleared", "cyan");
            }}>CLEAR LOCAL KEY</Btn>
            <Btn small tone="cyan" onClick={() => { if (keyDraft.trim()) { setUserKey(keyDraft.trim()); setKeyDraft(""); } setModal(null); selfTest(); }}>SAVE & SELF-TEST →</Btn>
          </div>
        </Modal>
      )}
      {modal === "help" && (
        <Modal title="HOW HELIX WORKS" onClose={() => setModal(null)}>
          <div style={{ fontFamily: SANS, fontSize: 13, lineHeight: 1.75, color: C.text }}>
            <p style={{ marginTop: 0 }}><b style={{ color: C.amber }}>The loop.</b> Every task runs PLANNER → EXECUTOR → CRITIC → OPTIMIZER. The critic scores 0–100 with named weaknesses; the optimizer decides whether to rewrite the worker prompts or adjust heuristics. Those prompts + heuristics are the <i>genome</i>.</p>
            <p><b style={{ color: C.amber }}>Lineages.</b> Five independent genomes — GENERAL, CLINICAL, DEV, FINANCE, DESIGN — each pre-seeded with domain heuristics and each evolving on its own. AUTO-ROUTE classifies your task and mounts the right lineage; a blinking chip means a switch is suggested. Tap any chip to override.</p>
            <p><b style={{ color: C.amber }}>◉ TRAIN (self-play).</b> The TRAINER agent reads this lineage's recent weaknesses and writes {TRAIN_ROUNDS} practice tasks specifically designed to stress them, then runs full evolution cycles unattended. This is how you improve the system without feeding it real work — run it while you make coffee.</p>
            <p><b style={{ color: C.amber }}>Adaptive pressure.</b> The optimizer's aggression scales with the fitness trend: declining scores → aggressive rewrites; plateau → moderate; climbing → conservative (don't fix what's working). Watch TREND in the top bar.</p>
            <p><b style={{ color: C.amber }}>DEPTH.</b> FAST executes the plan in one pass. DEEP executes step-by-step with a final synthesis pass — slower, meaningfully stronger on multi-part tasks (protocols, specs, models).</p>
            <p><b style={{ color: C.amber }}>🔍 RESEARCH.</b> Grants the executor live web search. Turn it on for anything needing current guidelines, prices, versions, or events.</p>
            <p><b style={{ color: C.amber }}>↻ Refine / ⚔ Tournament.</b> Refine revises a deliverable against the critic's weakness list and re-scores. Tournament runs your task through the current and previous genome, blind-judged; incumbent wins by &gt;5 → automatic rollback. Tournament is your empirical proof the evolution works.</p>
            <p><b style={{ color: C.amber }}>Safety rails.</b> Critic and Optimizer stay fixed by default (no grading itself on a curve). Every mutation snapshots the prior genome. The regression guard fires when a version underperforms its predecessor by &gt;{REGRESSION_DELTA}. Evolution modes: AUTO applies mutations, APPROVE shows you each diff first, OFF freezes.</p>
            <p style={{ marginBottom: 0 }}><b style={{ color: C.amber }}>Persistence.</b> Everything — all five genomes, memory, telemetry, history — lives in this browser's localStorage and survives closing the tab. It's per-device: train on your phone and that lineage lives on your phone. Use EXPORT/IMPORT on the genome panel to move trained genomes between devices.</p>
          </div>
        </Modal>
      )}
    </div>
  );
}
