import React from "react";
import { createRoot } from "react-dom/client";
import HelixOS from "./App.jsx";

createRoot(document.getElementById("root")).render(<HelixOS />);
