# HELIX OS

A self-improving agentic operating system. Every task runs through a four-agent
pipeline — **PLANNER → EXECUTOR → CRITIC → OPTIMIZER** — and the optimizer
rewrites the workers' own system prompts and heuristics based on the critic's
scored findings. Those prompts + heuristics are the *genome*: versioned,
diffable, rollback-able, and empirically testable.

Built with Claude (Anthropic) as the reasoning engine.

## Features

- **Five genome lineages** (general / clinical / dev / finance / design), each
  seeded with domain heuristics and evolving independently; keyword auto-routing
  mounts the right lineage per task
- **Self-play training** (`◉ TRAIN`) — a TRAINER agent writes practice tasks
  targeting the lineage's recent weaknesses and runs full evolution cycles unattended
- **Adaptive mutation pressure** — optimizer aggression scales with the fitness
  trend (declining → aggressive, climbing → conservative)
- **⚔ Tournaments** — current genome vs. previous version on the same task,
  blind-judged; losing challengers auto-rollback
- **↻ Refine loop**, evolution modes (AUTO / APPROVE / OFF), regression guard,
  manual prompt surgery, genome export/import
- **Episodic memory** with salience decay (λ=0.92), recall reinforcement, and
  per-lineage retrieval preference
- Fitness telemetry charts, task history with re-run benchmarking, kernel log,
  self-diagnosing `⚕ SELF-TEST`
- Fault-isolated pipeline: no single agent failure can destroy a deliverable

## Architecture

```
├── src/App.jsx        # the entire client — UI, agents, genome engine, memory
├── src/main.jsx       # entry
├── api/helix.js       # Vercel serverless proxy → Anthropic Messages API
├── api/health.js      # deployment + key status probe
└── index.html         # PWA meta (add-to-homescreen ready)
```

**Dual transport, auto-detected at boot:**

1. **PROXY** — if `/api/health` responds, calls route through this deployment's
   own serverless function, which holds `ANTHROPIC_API_KEY` server-side.
2. **DIRECT** — on static-only hosts (no functions), the browser calls the
   Anthropic API directly using a user-supplied key stored in `localStorage`,
   with the `anthropic-dangerous-direct-browser-access` header.

The client I/O layer is shim-safe (no `AbortSignal` or other non-cloneable
values in fetch init — timeouts via `Promise.race`), retries ×3 with jittered
backoff, fails fast on deterministic auth/billing errors, and keeps a
ring-buffer fault trace surfaced in the UI.

**Persistence:** all state (genomes, memory, telemetry, history, settings)
lives in `localStorage`, per-origin/per-device. Move trained genomes between
devices with EXPORT/IMPORT on the genome panel.

## Quickstart (local dev)

```bash
npm install
npm run dev          # Vite on :5173
```

For the proxy locally, run the functions with Vercel's dev server instead:

```bash
npx vercel dev       # serves the app + /api on one port
```

## Deploy

### Vercel (recommended — full proxy)

```bash
npx vercel --prod
```

Then set the key once: **Project → Settings → Environment Variables →
`ANTHROPIC_API_KEY`** → redeploy. Every device gets a working app with no
key in the browser. Connect the repo via Vercel's git integration and every
push to `main` auto-deploys.

### Any static host (DIRECT mode)

```bash
npm run build        # dist/index.html is fully self-contained (vite-plugin-singlefile)
```

Drop `dist/` on Netlify/Cloudflare Pages/anything. On first boot the app
detects the missing proxy, switches to DIRECT transport, and opens the 🔑 KEY
panel to collect a key (browser-local only).

## API key & security notes

- The proxy path keeps the key server-side; the `x-user-key` header fallback
  exists so a fresh deployment works before env vars are configured.
- DIRECT mode stores the key in the browser's `localStorage` on your own
  deployment — acceptable for personal use on your own devices; don't use it
  on shared machines, and prefer the proxy + env var for anything multi-user.
- API usage bills to the key's console.anthropic.com account (separate from a
  Claude app subscription). `⚕ SELF-TEST` detects unfunded accounts explicitly.

## Roadmap

- KV/database persistence (Vercel KV) for cross-device genome sync
- Streaming responses in the console
- MCP tool syscalls for the executor (PubMed, ChEMBL, calendars)
- A/B genome tournaments across arbitrary lineage pairs
- Scheduled overnight self-play via cron

## License

MIT
