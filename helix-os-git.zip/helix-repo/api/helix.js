/* HELIX serverless proxy — keeps the Anthropic key server-side.
   Key resolution order:
   1. ANTHROPIC_API_KEY env var (set in Vercel → Project → Settings → Environment Variables)
   2. x-user-key header (pasted by the operator into the app's KEY settings; stored only in their browser)
*/
export default async function handler(req, res) {
  res.setHeader("Cache-Control", "no-store");
  if (req.method !== "POST") {
    return res.status(405).json({ error: "method_not_allowed", message: "POST only" });
  }
  const key = process.env.ANTHROPIC_API_KEY || req.headers["x-user-key"];
  if (!key) {
    return res.status(401).json({
      error: "no_api_key",
      message: "No API key configured. Add ANTHROPIC_API_KEY in Vercel env vars, or paste a key into the app's KEY panel.",
    });
  }
  try {
    const { system, user, maxTokens = 2000, research = false } = req.body || {};
    if (!user) return res.status(400).json({ error: "bad_request", message: "missing user content" });
    const body = {
      model: "claude-sonnet-4-6",
      max_tokens: Math.max(64, Math.min(Number(maxTokens) || 2000, 4096)),
      messages: [{ role: "user", content: String(user) }],
    };
    if (system) body.system = String(system);
    if (research) body.tools = [{ type: "web_search_20250305", name: "web_search", max_uses: 3 }];

    const r = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "content-type": "application/json",
        "x-api-key": key,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify(body),
    });
    const raw = await r.text();
    let data;
    try { data = JSON.parse(raw); }
    catch {
      return res.status(502).json({ error: "upstream_non_json", message: `http ${r.status} :: ${raw.slice(0, 160)}` });
    }
    if (data.error) {
      return res.status(r.status || 500).json({
        error: data.error.type || "api_error",
        message: data.error.message || "unknown API error",
      });
    }
    const text = (data.content || [])
      .filter((b) => b.type === "text")
      .map((b) => b.text)
      .join("\n");
    return res.status(200).json({ text, stop: data.stop_reason || null });
  } catch (e) {
    return res.status(502).json({ error: "proxy_error", message: String(e?.message || e) });
  }
}
