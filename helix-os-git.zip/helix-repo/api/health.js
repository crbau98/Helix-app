export default function handler(req, res) {
  res.setHeader("Cache-Control", "no-store");
  res.status(200).json({
    ok: true,
    service: "helix-os",
    hasEnvKey: Boolean(process.env.ANTHROPIC_API_KEY),
    ts: new Date().toISOString(),
  });
}
